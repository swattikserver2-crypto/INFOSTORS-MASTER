# INFOSTORS — Final Admin Panel Source Export & Operations Guide

## 1. Project Overview
This repository contains the standalone, production-ready **INFOSTORS Professional Admin Panel** source package. It is designed to be downloaded, opened directly in VS Code, and operated either with its local standalone Express API or connected to the production **INFOSTORS Supabase** database.

- **Scope**: Dedicated Administrative Operations Suite exclusively.
- **Technology Stack**: React 18, TypeScript, Tailwind CSS, Vite, Node.js / Express, PostgreSQL / Supabase, Lucide Icons.
- **Provider Independence**: Built on a clean repository abstraction layer (`src/shared/interfaces/repository.interfaces.ts`). The UI is completely decoupled from any single backend vendor.
- **Zero Third-Party Spreadsheet Reliance**: Operates with a normalized relational database foundation; no external Google Sheets or Apps Script dependencies.

---

## 2. Quick Start & Local Development

### Prerequisites
- **Node.js**: v18.x or v20.x LTS
- **Package Manager**: npm (v9+), bun, or pnpm

### Installation
```bash
# Install dependencies
npm install
```

### Environment Configuration
Copy `.env.example` to create your local `.env`:
```bash
cp .env.example .env
```
Populate `.env` with your development or production keys (never commit secrets to version control):
```env
PORT=3000
NODE_ENV=development
JWT_SECRET=your-secure-random-jwt-secret-min-32-chars
ENCRYPTION_KEY=your-aes256-master-encryption-key-32-chars

# Supabase Configuration (Optional for local mode, required for live Supabase)
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-supabase-service-role-key-server-only
```

### Running Locally
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser. The application will route directly to the Admin Portal.

---

## 3. Connecting to the Real Supabase Project

1. **Deploy Migrations**:
   Navigate to the `supabase/` folder and push the migrations using the Supabase CLI:
   ```bash
   supabase login
   supabase link --project-ref <your-supabase-project-id>
   supabase db push
   ```
   Or execute the scripts sequentially in the Supabase Dashboard SQL Editor:
   - `supabase/migrations/20260925000001_initial_schema.sql` (18 tables, indexes, constraints)
   - `supabase/migrations/20260925000002_functions_triggers.sql` (Monotonic order IDs, stock triggers)
   - `supabase/migrations/20260925000003_rls_security_policies.sql` (Row Level Security policies)
   - `supabase/migrations/20260925000004_storage_buckets.sql` (Storage buckets & policies)

2. **Seed Initial Data**:
   ```bash
   supabase db seed
   ```
   Or execute `supabase/seed/seed.sql` to populate default roles, permissions, store settings, categories, and initial products.

3. **Set Environment Keys**:
   In your hosting environment or `.env`, set:
   - `VITE_SUPABASE_URL`: Your Supabase Project API URL.
   - `VITE_SUPABASE_ANON_KEY`: Your Supabase Anonymous Public Key.
   - `SUPABASE_SERVICE_ROLE_KEY`: Server-side service key (never exposed to frontend).

---

## 4. Production Build & Deployment

### Build Command
```bash
npm run build
```
This runs `tsc -b && vite build` for the frontend and bundles `server.ts` using `esbuild`.

### Start Command (Full-Stack)
```bash
npm run start
```

### Node.js Full-Stack Hosting
- This production build requires Node.js because the Express API handles authentication, orders, inventory and payments.
- Build: `npm run build`
- Start: `npm start`
- Set all production environment variables from `.env.example`.
- `/health` verifies that the application can reach Supabase.

---

## 5. Migration Files & Data Contract Locations

- **Database Migrations**: `supabase/migrations/`
- **Database Seed Script**: `supabase/seed/seed.sql`
- **RLS Security Policies Reference**: `supabase/policies/rls_policies_reference.sql`
- **Database Architecture Spec**: `INFOSTORS_SUPABASE_DATABASE_ARCHITECTURE.md`
- **Data Structure & API Contract**:
  - `docs/INFOSTORS_FINAL_DATA_STRUCTURE_API_CONTRACT.md` (Human-readable specification)
  - `docs/INFOSTORS_FINAL_DATA_STRUCTURE_API_CONTRACT.json` (Machine-readable JSON schema)
- **Environment Setup Guide**: `docs/INFOSTORS_ENVIRONMENT_SETUP.md`
- **File Manifest**: `docs/INFOSTORS_ADMIN_FILE_MANIFEST.md`
- **Connection Map**: `docs/INFOSTORS_ADMIN_SUPABASE_CONNECTION_MAP.md`

---

## 6. Security Warnings & Best Practices

1. **NEVER Expose Service Role Keys**: `SUPABASE_SERVICE_ROLE_KEY` bypasses all Row Level Security. It must only ever be accessed in server-side processes (`server.ts`).
2. **Encrypted Payment Secrets**: Razorpay secrets configured in the admin UI or database are encrypted using AES-256-CBC at rest with `ENCRYPTION_KEY`.
3. **Two-Man Rule Destruction**: Destructive actions on orders or customer accounts must be submitted as requests and reviewed by the Main Administrator.
4. **Immutable Audit Logs**: The `audit_logs` table has no `UPDATE` or `DELETE` grants in PostgreSQL.

---

## 7. Verification Summary

### Verified
- **TypeScript Typecheck (`npm run lint` / `tsc --noEmit`)**: VERIFIED (0 errors).
- **Production Build (`npm run build`)**: VERIFIED (Passes cleanly).
- **Standalone Admin Routing**: VERIFIED (Loads Admin App cleanly).
- **Data Contract & Migration Files**: VERIFIED (All SQL migrations, contracts, and docs present).
- **Provider Independence**: VERIFIED (Repository pattern abstracts Supabase from the React UI).

### Not Verified
- **Live Supabase Remote Connection**: NOT VERIFIED (Requires user's actual remote Supabase project URL and anon key).
- **Live Razorpay Webhook Callbacks**: NOT VERIFIED (Requires live internet-reachable webhook URL).
