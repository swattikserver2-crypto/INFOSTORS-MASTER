-- ============================================================================
-- INFOSTORS FINAL PRODUCTION SUPABASE MASTER DATABASE SCRIPT
-- ============================================================================
-- Target Supabase Project ID: oewerfftzqklptdsdfrm
-- Target Project URL: https://oewerfftzqklptdsdfrm.supabase.co
-- Source of Truth: INFOSTORS_FINAL_DATA_STRUCTURE_API_CONTRACT.md (v1.0.0)
-- Safety Guarantee: Non-destructive, idempotent (IF NOT EXISTS / ON CONFLICT)
-- DO NOT expose service_role or API keys inside this SQL file.
-- ============================================================================

-- ============================================================================
-- SECTION 1: EXTENSIONS
-- ============================================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- SECTION 2: CUSTOM ENUM TYPES
-- ============================================================================
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'payment_method_enum') THEN
        CREATE TYPE public.payment_method_enum AS ENUM ('razorpay', 'upi', 'cod');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'payment_status_enum') THEN
        CREATE TYPE public.payment_status_enum AS ENUM ('pending', 'authorized', 'paid', 'failed', 'refunded');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'order_status_enum') THEN
        CREATE TYPE public.order_status_enum AS ENUM ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'package_status_enum') THEN
        CREATE TYPE public.package_status_enum AS ENUM ('received', 'dispatched', 'delivered', 'cancelled');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'delete_request_status_enum') THEN
        CREATE TYPE public.delete_request_status_enum AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'COMPLETED', 'FAILED');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'audit_log_result_enum') THEN
        CREATE TYPE public.audit_log_result_enum AS ENUM ('SUCCESS', 'FAILED', 'REJECTED');
    END IF;
END $$;

-- ============================================================================
-- SECTION 3: CORE RELATIONAL TABLES
-- ============================================================================

-- 1. RBAC SYSTEM
CREATE TABLE IF NOT EXISTS public.roles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.permissions (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    module TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.role_permissions (
    role_id TEXT NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
    permission_id TEXT NOT NULL REFERENCES public.permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS public.admin_users (
    id TEXT PRIMARY KEY,
    auth_user_id UUID UNIQUE,
    email TEXT NOT NULL UNIQUE,
    mobile TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL REFERENCES public.roles(id) DEFAULT 'admin',
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disabled')),
    created_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. CUSTOMER DIRECTORY & ADDRESSES
CREATE TABLE IF NOT EXISTS public.customers (
    id TEXT PRIMARY KEY,
    auth_user_id UUID UNIQUE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    mobile TEXT NOT NULL UNIQUE CHECK (mobile ~ '^[6-9][0-9]{9}$'),
    address TEXT,
    city TEXT,
    state TEXT,
    pincode TEXT CHECK (pincode IS NULL OR pincode ~ '^[0-9]{6}$'),
    total_orders INTEGER NOT NULL DEFAULT 0 CHECK (total_orders >= 0),
    total_spent NUMERIC(12, 2) NOT NULL DEFAULT 0.00 CHECK (total_spent >= 0),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.customer_addresses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id TEXT NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL CHECK (phone ~ '^[6-9][0-9]{9}$'),
    address_line1 TEXT NOT NULL,
    address_line2 TEXT,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    pincode TEXT NOT NULL CHECK (pincode ~ '^[0-9]{6}$'),
    is_default BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 3. CATEGORIES & PRODUCTS
CREATE TABLE IF NOT EXISTS public.categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    emoji TEXT NOT NULL DEFAULT '📦',
    description TEXT NOT NULL,
    icon_name TEXT,
    banner_image TEXT,
    display_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.products (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category_id TEXT NOT NULL REFERENCES public.categories(id) ON DELETE RESTRICT,
    brand TEXT NOT NULL DEFAULT 'INFOSTORS',
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    original_price NUMERIC(10, 2) NOT NULL CHECK (original_price >= price),
    discount_percentage INTEGER GENERATED ALWAYS AS (
        CASE 
            WHEN original_price > 0 AND original_price > price 
            THEN ROUND(((original_price - price) / original_price) * 100)::INTEGER 
            ELSE 0 
        END
    ) STORED,
    image_url TEXT NOT NULL,
    gallery_images JSONB NOT NULL DEFAULT '[]'::jsonb,
    short_description TEXT NOT NULL,
    description TEXT NOT NULL,
    features JSONB NOT NULL DEFAULT '[]'::jsonb,
    stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
    rating NUMERIC(3, 2) NOT NULL DEFAULT 4.80 CHECK (rating >= 1.0 AND rating <= 5.0),
    reviews_count INTEGER NOT NULL DEFAULT 0 CHECK (reviews_count >= 0),
    is_trending BOOLEAN NOT NULL DEFAULT false,
    is_bestseller BOOLEAN NOT NULL DEFAULT false,
    is_new_arrival BOOLEAN NOT NULL DEFAULT false,
    is_deal BOOLEAN NOT NULL DEFAULT false,
    badge TEXT,
    warranty TEXT DEFAULT '1 Year Brand Replacement Warranty',
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 4. INVENTORY LOGS
CREATE TABLE IF NOT EXISTS public.inventory_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id TEXT NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    change_amount INTEGER NOT NULL,
    previous_stock INTEGER NOT NULL CHECK (previous_stock >= 0),
    new_stock INTEGER NOT NULL CHECK (new_stock >= 0),
    reason TEXT NOT NULL CHECK (reason IN ('order_placed', 'order_cancelled', 'admin_adjustment', 'restock', 'damage_writeoff')),
    order_id TEXT,
    notes TEXT,
    created_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 5. ORDERS & ORDER ITEMS
CREATE TABLE IF NOT EXISTS public.orders (
    id TEXT PRIMARY KEY,
    customer_id TEXT REFERENCES public.customers(id) ON DELETE SET NULL,
    customer_name TEXT NOT NULL,
    customer_phone TEXT NOT NULL CHECK (customer_phone ~ '^[6-9][0-9]{9}$'),
    customer_email TEXT NOT NULL,
    shipping_address TEXT NOT NULL,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    pincode TEXT NOT NULL CHECK (pincode ~ '^[0-9]{6}$'),
    subtotal NUMERIC(10, 2) NOT NULL CHECK (subtotal >= 0),
    discount_amount NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (discount_amount >= 0),
    shipping_fee NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (shipping_fee >= 0),
    tax_amount NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (tax_amount >= 0),
    grand_total NUMERIC(10, 2) NOT NULL CHECK (grand_total > 0),
    currency TEXT NOT NULL DEFAULT 'INR' CHECK (currency = 'INR'),
    payment_method TEXT NOT NULL CHECK (payment_method IN ('razorpay', 'upi', 'cod')),
    payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'authorized', 'paid', 'failed', 'refunded')),
    order_status TEXT NOT NULL DEFAULT 'pending' CHECK (order_status IN ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled')),
    package_status TEXT NOT NULL DEFAULT 'received' CHECK (package_status IN ('received', 'dispatched', 'delivered', 'cancelled')),
    razorpay_order_id TEXT,
    razorpay_payment_id TEXT,
    razorpay_signature TEXT,
    payment_failure_reason TEXT,
    courier_partner TEXT DEFAULT 'Delhivery Express',
    tracking_id TEXT,
    estimated_delivery_date TEXT,
    resolution TEXT,
    b2b_company_name TEXT,
    b2b_gstin TEXT,
    tax_breakdown JSONB NOT NULL DEFAULT '{}'::jsonb,
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id TEXT NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id TEXT NOT NULL REFERENCES public.products(id) ON DELETE RESTRICT,
    product_name TEXT NOT NULL,
    unit_price NUMERIC(10, 2) NOT NULL CHECK (unit_price >= 0),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    total_price NUMERIC(10, 2) NOT NULL CHECK (total_price >= 0),
    image_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.order_status_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id TEXT NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    previous_status TEXT,
    new_status TEXT NOT NULL,
    changed_by TEXT NOT NULL,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 6. STORE SETTINGS & PAYMENT GATEWAY CREDENTIALS
CREATE TABLE IF NOT EXISTS public.store_settings (
    id TEXT PRIMARY KEY DEFAULT 'default' CHECK (id = 'default'),
    store_name TEXT NOT NULL DEFAULT 'INFOSTORS',
    tagline TEXT NOT NULL DEFAULT 'Smart Gadgets | Better Life',
    logo_url TEXT DEFAULT '',
    header_logo_height INTEGER DEFAULT 72,
    helpline TEXT NOT NULL DEFAULT '+91 94778 39200 (Toll Free / WhatsApp)',
    email TEXT NOT NULL DEFAULT 'contactinfostors@gmail.com',
    office_address TEXT NOT NULL DEFAULT 'INFOSTORS Headquarters, Garia station road, Kolkata 700084, India',
    standard_delivery_charge NUMERIC(8, 2) NOT NULL DEFAULT 49.00 CHECK (standard_delivery_charge >= 0),
    free_delivery_min NUMERIC(8, 2) NOT NULL DEFAULT 499.00 CHECK (free_delivery_min >= 0),
    enable_free_delivery_threshold BOOLEAN NOT NULL DEFAULT true,
    announcement TEXT NOT NULL DEFAULT 'Free Delivery on all orders above ₹499 across India',
    whatsapp_url TEXT NOT NULL DEFAULT 'https://wa.me/919477839200',
    instagram_url TEXT NOT NULL DEFAULT 'https://www.instagram.com/infostors',
    facebook_url TEXT NOT NULL DEFAULT 'https://www.facebook.com/Infostors',
    youtube_url TEXT NOT NULL DEFAULT 'https://www.youtube.com/@InfoStors',
    return_window TEXT DEFAULT '7 Days Replacement Guarantee',
    business_legal_name TEXT DEFAULT 'INFOSTORS ENTERPRISES PRIVATE LIMITED',
    trade_name TEXT DEFAULT 'INFOSTORS',
    owner_name TEXT DEFAULT 'InfoStors Management',
    pan TEXT DEFAULT 'AAACI1234F',
    gst_enabled BOOLEAN NOT NULL DEFAULT false,
    gstin TEXT DEFAULT '19AAACI1234F1Z8',
    gst_percentage NUMERIC(5, 2) NOT NULL DEFAULT 18.00 CHECK (gst_percentage >= 0 AND gst_percentage <= 100),
    gst_type TEXT NOT NULL DEFAULT 'inclusive' CHECK (gst_type IN ('inclusive', 'exclusive')),
    gst_state TEXT DEFAULT '19 - West Bengal',
    show_gstin_on_invoice BOOLEAN NOT NULL DEFAULT true,
    allow_customer_b2b_gst BOOLEAN NOT NULL DEFAULT true,
    pwa_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    whatsapp_notification_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    shipping_label_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_by TEXT
);

CREATE TABLE IF NOT EXISTS public.payment_settings (
    id TEXT PRIMARY KEY DEFAULT 'default' CHECK (id = 'default'),
    mode TEXT NOT NULL DEFAULT 'live' CHECK (mode IN ('test', 'live')),
    key_id TEXT NOT NULL DEFAULT '',
    key_secret_encrypted TEXT,
    webhook_secret_encrypted TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_by TEXT
);

-- 7. TWO-MAN RULE DESTRUCTION GOVERNANCE
CREATE TABLE IF NOT EXISTS public.delete_requests (
    id TEXT PRIMARY KEY,
    target_type TEXT NOT NULL CHECK (target_type IN ('order', 'customer')),
    target_id TEXT NOT NULL,
    target_summary TEXT NOT NULL,
    requested_by_email TEXT NOT NULL,
    requested_by_name TEXT,
    requested_by_role TEXT NOT NULL CHECK (requested_by_role IN ('main_admin', 'admin')),
    reason TEXT NOT NULL CHECK (length(reason) >= 5),
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED', 'COMPLETED', 'FAILED')),
    reviewed_by_email TEXT,
    reviewed_by_name TEXT,
    reviewed_at TIMESTAMPTZ,
    rejection_reason TEXT,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 8. SECURITY AUDIT LOGS
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id TEXT PRIMARY KEY,
    admin_email TEXT NOT NULL,
    admin_name TEXT,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    reason TEXT,
    result TEXT NOT NULL CHECK (result IN ('SUCCESS', 'FAILED', 'REJECTED')),
    details TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 9. TARGETED CUSTOMER MESSAGES & NOTIFICATIONS
CREATE TABLE IF NOT EXISTS public.customer_messages (
    id TEXT PRIMARY KEY,
    customer_id TEXT NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
    customer_email TEXT,
    customer_mobile TEXT,
    sender_type TEXT NOT NULL CHECK (sender_type IN ('admin', 'customer')),
    sender_name TEXT NOT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    message_type TEXT NOT NULL CHECK (message_type IN ('offer', 'order_update', 'recommendation', 'support')),
    is_read BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.notifications (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    target_audience TEXT NOT NULL CHECK (target_audience IN ('all', 'segment', 'selected', 'individual')),
    target_customer_id TEXT REFERENCES public.customers(id) ON DELETE CASCADE,
    category TEXT NOT NULL CHECK (category IN ('special_offer', 'order_update', 'new_product', 'restock', 'promo')),
    status TEXT NOT NULL DEFAULT 'sent' CHECK (status IN ('sent', 'queued', 'not_configured')),
    sent_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 10. CUSTOMER CART & WISHLIST
CREATE TABLE IF NOT EXISTS public.customer_carts (
    customer_id TEXT PRIMARY KEY REFERENCES public.customers(id) ON DELETE CASCADE,
    items JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.customer_wishlists (
    customer_id TEXT NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
    product_id TEXT NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    PRIMARY KEY (customer_id, product_id)
);

-- ============================================================================
-- SECTION 4: PERFORMANCE INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_products_category_id ON public.products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_is_active ON public.products(is_active);
CREATE INDEX IF NOT EXISTS idx_products_price ON public.products(price);
CREATE INDEX IF NOT EXISTS idx_products_rating ON public.products(rating DESC);
CREATE INDEX IF NOT EXISTS idx_products_stock ON public.products(stock);
CREATE INDEX IF NOT EXISTS idx_products_created_at ON public.products(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON public.orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer_phone ON public.orders(customer_phone);
CREATE INDEX IF NOT EXISTS idx_orders_customer_email ON public.orders(customer_email);
CREATE INDEX IF NOT EXISTS idx_orders_order_status ON public.orders(order_status);
CREATE INDEX IF NOT EXISTS idx_orders_package_status ON public.orders(package_status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON public.orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_tracking_id ON public.orders(tracking_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON public.order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_order_status_history_order_id ON public.order_status_history(order_id);

CREATE INDEX IF NOT EXISTS idx_customers_mobile ON public.customers(mobile);
CREATE INDEX IF NOT EXISTS idx_customers_email ON public.customers(email);
CREATE INDEX IF NOT EXISTS idx_customers_auth_user_id ON public.customers(auth_user_id);
CREATE INDEX IF NOT EXISTS idx_customer_addresses_customer_id ON public.customer_addresses(customer_id);

CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON public.audit_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON public.audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_delete_requests_status ON public.delete_requests(status);
CREATE INDEX IF NOT EXISTS idx_customer_messages_customer_id ON public.customer_messages(customer_id);
CREATE INDEX IF NOT EXISTS idx_notifications_target_audience ON public.notifications(target_audience);
CREATE INDEX IF NOT EXISTS idx_inventory_logs_product_id ON public.inventory_logs(product_id);

-- ============================================================================
-- SECTION 5: FUNCTIONS & TRIGGERS
-- ============================================================================
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_set_updated_at_products ON public.products;
CREATE TRIGGER trigger_set_updated_at_products
    BEFORE UPDATE ON public.products
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_categories ON public.categories;
CREATE TRIGGER trigger_set_updated_at_categories
    BEFORE UPDATE ON public.categories
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_customers ON public.customers;
CREATE TRIGGER trigger_set_updated_at_customers
    BEFORE UPDATE ON public.customers
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_customer_addresses ON public.customer_addresses;
CREATE TRIGGER trigger_set_updated_at_customer_addresses
    BEFORE UPDATE ON public.customer_addresses
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_orders ON public.orders;
CREATE TRIGGER trigger_set_updated_at_orders
    BEFORE UPDATE ON public.orders
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_admin_users ON public.admin_users;
CREATE TRIGGER trigger_set_updated_at_admin_users
    BEFORE UPDATE ON public.admin_users
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_store_settings ON public.store_settings;
CREATE TRIGGER trigger_set_updated_at_store_settings
    BEFORE UPDATE ON public.store_settings
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Monotonic collision-safe daily order ID
CREATE OR REPLACE FUNCTION public.generate_order_id()
RETURNS TEXT AS $$
DECLARE
    date_prefix TEXT;
    today_count INTEGER;
    candidate_id TEXT;
BEGIN
    date_prefix := 'INF-' || to_char(timezone('Asia/Kolkata', now()), 'YYYYMMDD');
    SELECT count(*) INTO today_count
    FROM public.orders
    WHERE id LIKE date_prefix || '-%';
    
    today_count := today_count + 1;
    candidate_id := date_prefix || '-' || lpad(today_count::TEXT, 4, '0');
    
    WHILE EXISTS (SELECT 1 FROM public.orders WHERE id = candidate_id) LOOP
        today_count := today_count + 1;
        candidate_id := date_prefix || '-' || lpad(today_count::TEXT, 4, '0');
    END LOOP;
    
    RETURN candidate_id;
END;
$$ LANGUAGE plpgsql VOLATILE;

-- Order status history recorder
CREATE OR REPLACE FUNCTION public.record_order_status_change()
RETURNS TRIGGER AS $$
BEGIN
    IF (OLD.order_status IS DISTINCT FROM NEW.order_status) OR (OLD.package_status IS DISTINCT FROM NEW.package_status) THEN
        INSERT INTO public.order_status_history (
            order_id,
            previous_status,
            new_status,
            changed_by,
            notes
        ) VALUES (
            NEW.id,
            COALESCE(OLD.order_status, '') || ' (' || COALESCE(OLD.package_status, '') || ')',
            COALESCE(NEW.order_status, '') || ' (' || COALESCE(NEW.package_status, '') || ')',
            COALESCE(current_setting('app.current_user', true), 'system'),
            NEW.resolution
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_record_order_status_change ON public.orders;
CREATE TRIGGER trigger_record_order_status_change
    AFTER UPDATE ON public.orders
    FOR EACH ROW EXECUTE FUNCTION public.record_order_status_change();

-- Atomic inventory deduction trigger
CREATE OR REPLACE FUNCTION public.deduct_inventory_for_order_item()
RETURNS TRIGGER AS $$
DECLARE
    curr_stock INTEGER;
BEGIN
    SELECT stock INTO curr_stock
    FROM public.products
    WHERE id = NEW.product_id
    FOR UPDATE;

    IF curr_stock IS NULL THEN
        RAISE EXCEPTION 'Product % does not exist in catalog', NEW.product_id;
    END IF;

    IF curr_stock < NEW.quantity THEN
        RAISE EXCEPTION 'Insufficient inventory for product %. Available: %, Requested: %', 
            NEW.product_id, curr_stock, NEW.quantity;
    END IF;

    UPDATE public.products
    SET stock = stock - NEW.quantity
    WHERE id = NEW.product_id;

    INSERT INTO public.inventory_logs (
        product_id,
        change_amount,
        previous_stock,
        new_stock,
        reason,
        order_id,
        notes,
        created_by
    ) VALUES (
        NEW.product_id,
        -NEW.quantity,
        curr_stock,
        curr_stock - NEW.quantity,
        'order_placed',
        NEW.order_id,
        'Order placement auto-deduction for ' || NEW.order_id,
        'system'
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_deduct_inventory_order_item ON public.order_items;
CREATE TRIGGER trigger_deduct_inventory_order_item
    AFTER INSERT ON public.order_items
    FOR EACH ROW EXECUTE FUNCTION public.deduct_inventory_for_order_item();

-- Security definer functions for RLS
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.admin_users
        WHERE auth_user_id = auth.uid()
          AND status = 'active'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION public.is_main_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.admin_users
        WHERE auth_user_id = auth.uid()
          AND role = 'main_admin'
          AND status = 'active'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION public.has_permission(required_permission TEXT)
RETURNS BOOLEAN AS $$
BEGIN
    IF public.is_main_admin() THEN
        RETURN true;
    END IF;

    RETURN EXISTS (
        SELECT 1 
        FROM public.admin_users au
        JOIN public.role_permissions rp ON au.role = rp.role_id
        WHERE au.auth_user_id = auth.uid()
          AND au.status = 'active'
          AND rp.permission_id = required_permission
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- ============================================================================
-- SECTION 6: ROW LEVEL SECURITY & POLICIES
-- ============================================================================
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delete_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_carts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_wishlists ENABLE ROW LEVEL SECURITY;

-- Products & Categories
DROP POLICY IF EXISTS "Public can view active products" ON public.products;
CREATE POLICY "Public can view active products" 
    ON public.products FOR SELECT 
    USING (is_active = true OR public.is_admin());

DROP POLICY IF EXISTS "Admins with permission can manage products" ON public.products;
CREATE POLICY "Admins with permission can manage products" 
    ON public.products FOR ALL 
    USING (public.has_permission('products.write'))
    WITH CHECK (public.has_permission('products.write'));

DROP POLICY IF EXISTS "Public can view categories" ON public.categories;
CREATE POLICY "Public can view categories" 
    ON public.categories FOR SELECT 
    USING (true);

DROP POLICY IF EXISTS "Admins with permission can manage categories" ON public.categories;
CREATE POLICY "Admins with permission can manage categories" 
    ON public.categories FOR ALL 
    USING (public.has_permission('products.write'))
    WITH CHECK (public.has_permission('products.write'));

-- Customers & Addresses
DROP POLICY IF EXISTS "Customer can view own profile" ON public.customers;
CREATE POLICY "Customer can view own profile" 
    ON public.customers FOR SELECT 
    USING (auth_user_id = auth.uid() OR public.has_permission('customers.read'));

DROP POLICY IF EXISTS "Customer can update own profile" ON public.customers;
CREATE POLICY "Customer can update own profile" 
    ON public.customers FOR UPDATE 
    USING (auth_user_id = auth.uid() OR public.has_permission('customers.read'))
    WITH CHECK (auth_user_id = auth.uid() OR public.has_permission('customers.read'));

DROP POLICY IF EXISTS "Customer can manage own addresses" ON public.customer_addresses;
CREATE POLICY "Customer can manage own addresses" 
    ON public.customer_addresses FOR ALL 
    USING (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) OR public.has_permission('customers.read'))
    WITH CHECK (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()));

-- Orders & Items
DROP POLICY IF EXISTS "Customer can view own orders" ON public.orders;
CREATE POLICY "Customer can view own orders" 
    ON public.orders FOR SELECT 
    USING (
        customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) 
        OR public.has_permission('orders.read')
    );

DROP POLICY IF EXISTS "Customer can insert order" ON public.orders;
CREATE POLICY "Customer can insert order" 
    ON public.orders FOR INSERT 
    WITH CHECK (true);

DROP POLICY IF EXISTS "Admins with permission can update orders" ON public.orders;
CREATE POLICY "Admins with permission can update orders" 
    ON public.orders FOR UPDATE 
    USING (public.has_permission('orders.write'))
    WITH CHECK (public.has_permission('orders.write'));

DROP POLICY IF EXISTS "Main admin can delete orders" ON public.orders;
CREATE POLICY "Main admin can delete orders" 
    ON public.orders FOR DELETE 
    USING (public.is_main_admin());

DROP POLICY IF EXISTS "Order items readable if order readable" ON public.order_items;
CREATE POLICY "Order items readable if order readable" 
    ON public.order_items FOR SELECT 
    USING (
        order_id IN (
            SELECT id FROM public.orders 
            WHERE customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) 
               OR public.has_permission('orders.read')
        )
    );

DROP POLICY IF EXISTS "Order items insertable" ON public.order_items;
CREATE POLICY "Order items insertable" 
    ON public.order_items FOR INSERT 
    WITH CHECK (true);

DROP POLICY IF EXISTS "Order status history readable" ON public.order_status_history;
CREATE POLICY "Order status history readable" 
    ON public.order_status_history FOR SELECT 
    USING (
        order_id IN (
            SELECT id FROM public.orders 
            WHERE customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) 
               OR public.has_permission('orders.read')
        )
    );

-- Store Settings & Payment Settings
DROP POLICY IF EXISTS "Public can view store settings" ON public.store_settings;
CREATE POLICY "Public can view store settings" 
    ON public.store_settings FOR SELECT 
    USING (true);

DROP POLICY IF EXISTS "Admins can update store settings" ON public.store_settings;
CREATE POLICY "Admins can update store settings" 
    ON public.store_settings FOR UPDATE 
    USING (public.has_permission('settings.write'))
    WITH CHECK (public.has_permission('settings.write'));

DROP POLICY IF EXISTS "Admins can view payment settings" ON public.payment_settings;
CREATE POLICY "Admins can view payment settings" 
    ON public.payment_settings FOR SELECT 
    USING (public.has_permission('payments.read'));

DROP POLICY IF EXISTS "Main Admin can update payment settings" ON public.payment_settings;
CREATE POLICY "Main Admin can update payment settings" 
    ON public.payment_settings FOR UPDATE 
    USING (public.is_main_admin())
    WITH CHECK (public.is_main_admin());

-- Two-Man Rule Destruction & Audit
DROP POLICY IF EXISTS "Admins can view delete requests" ON public.delete_requests;
CREATE POLICY "Admins can view delete requests" 
    ON public.delete_requests FOR SELECT 
    USING (public.is_admin());

DROP POLICY IF EXISTS "Admins can submit delete requests" ON public.delete_requests;
CREATE POLICY "Admins can submit delete requests" 
    ON public.delete_requests FOR INSERT 
    WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Main Admin can review delete requests" ON public.delete_requests;
CREATE POLICY "Main Admin can review delete requests" 
    ON public.delete_requests FOR UPDATE 
    USING (public.is_main_admin())
    WITH CHECK (public.is_main_admin());

DROP POLICY IF EXISTS "Admins can view audit logs" ON public.audit_logs;
CREATE POLICY "Admins can view audit logs" 
    ON public.audit_logs FOR SELECT 
    USING (public.has_permission('activity.read'));

DROP POLICY IF EXISTS "System and Admins can insert audit logs" ON public.audit_logs;
CREATE POLICY "System and Admins can insert audit logs" 
    ON public.audit_logs FOR INSERT 
    WITH CHECK (true);

-- Customer Messages & Notifications
DROP POLICY IF EXISTS "Customer can view own messages" ON public.customer_messages;
CREATE POLICY "Customer can view own messages" 
    ON public.customer_messages FOR SELECT 
    USING (
        customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) 
        OR public.is_admin()
    );

DROP POLICY IF EXISTS "Admins can send customer messages" ON public.customer_messages;
CREATE POLICY "Admins can send customer messages" 
    ON public.customer_messages FOR INSERT 
    WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Customer can update read status of own message" ON public.customer_messages;
CREATE POLICY "Customer can update read status of own message" 
    ON public.customer_messages FOR UPDATE 
    USING (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()))
    WITH CHECK (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()));

DROP POLICY IF EXISTS "Users can view relevant notifications" ON public.notifications;
CREATE POLICY "Users can view relevant notifications" 
    ON public.notifications FOR SELECT 
    USING (
        target_audience = 'all' 
        OR target_customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid())
        OR public.is_admin()
    );

DROP POLICY IF EXISTS "Admins can manage notifications" ON public.notifications;
CREATE POLICY "Admins can manage notifications" 
    ON public.notifications FOR ALL 
    USING (public.is_admin())
    WITH CHECK (public.is_admin());

-- Customer Cart & Wishlist
DROP POLICY IF EXISTS "Customer can manage own cart" ON public.customer_carts;
CREATE POLICY "Customer can manage own cart" 
    ON public.customer_carts FOR ALL 
    USING (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()))
    WITH CHECK (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()));

DROP POLICY IF EXISTS "Customer can manage own wishlist" ON public.customer_wishlists;
CREATE POLICY "Customer can manage own wishlist" 
    ON public.customer_wishlists FOR ALL 
    USING (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()))
    WITH CHECK (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()));

-- ============================================================================
-- SECTION 7: STORAGE BUCKETS & POLICIES
-- ============================================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
    (
        'product-images', 
        'product-images', 
        true, 
        10485760,
        ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml']
    ),
    (
        'store-assets', 
        'store-assets', 
        true, 
        5242880,
        ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml', 'application/json']
    ),
    (
        'invoices', 
        'invoices', 
        false,
        10485760, 
        ARRAY['application/pdf']
    ),
    (
        'shipping-labels', 
        'shipping-labels', 
        false,
        10485760, 
        ARRAY['application/pdf', 'image/png']
    )
ON CONFLICT (id) DO UPDATE SET
    public = EXCLUDED.public,
    file_size_limit = EXCLUDED.file_size_limit,
    allowed_mime_types = EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "Public read product images" ON storage.objects;
CREATE POLICY "Public read product images"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'product-images');

DROP POLICY IF EXISTS "Admins can upload product images" ON storage.objects;
CREATE POLICY "Admins can upload product images"
    ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'product-images' AND public.has_permission('products.write'));

DROP POLICY IF EXISTS "Admins can update product images" ON storage.objects;
CREATE POLICY "Admins can update product images"
    ON storage.objects FOR UPDATE
    USING (bucket_id = 'product-images' AND public.has_permission('products.write'));

DROP POLICY IF EXISTS "Admins can delete product images" ON storage.objects;
CREATE POLICY "Admins can delete product images"
    ON storage.objects FOR DELETE
    USING (bucket_id = 'product-images' AND public.has_permission('products.write'));

DROP POLICY IF EXISTS "Public read store assets" ON storage.objects;
CREATE POLICY "Public read store assets"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'store-assets');

DROP POLICY IF EXISTS "Admins can manage store assets" ON storage.objects;
CREATE POLICY "Admins can manage store assets"
    ON storage.objects FOR ALL
    USING (bucket_id = 'store-assets' AND public.has_permission('settings.write'))
    WITH CHECK (bucket_id = 'store-assets' AND public.has_permission('settings.write'));

DROP POLICY IF EXISTS "Customer can read own invoice" ON storage.objects;
CREATE POLICY "Customer can read own invoice"
    ON storage.objects FOR SELECT
    USING (
        bucket_id = 'invoices' 
        AND (
            public.is_admin()
            OR (auth.uid() IS NOT NULL AND name LIKE (auth.uid()::text || '/%'))
        )
    );

DROP POLICY IF EXISTS "Server and Admins can upload invoices" ON storage.objects;
CREATE POLICY "Server and Admins can upload invoices"
    ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'invoices' AND (public.is_admin() OR auth.role() = 'service_role'));

DROP POLICY IF EXISTS "Admins can access shipping labels" ON storage.objects;
CREATE POLICY "Admins can access shipping labels"
    ON storage.objects FOR ALL
    USING (bucket_id = 'shipping-labels' AND public.has_permission('orders.write'))
    WITH CHECK (bucket_id = 'shipping-labels' AND public.has_permission('orders.write'));

-- ============================================================================
-- SECTION 8: SEED DATA
-- ============================================================================
INSERT INTO public.roles (id, name, description)
VALUES 
    ('main_admin', 'Primary Main Administrator', 'Complete unrestricted access including destructive operations, financial secrets and user management'),
    ('admin', 'Store Operations Administrator', 'Catalog management, inventory adjustments, order processing and tracking'),
    ('support', 'Customer Support Specialist', 'Read-only access to customer profiles and orders for customer assistance')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.permissions (id, name, module, description)
VALUES 
    ('products.read', 'View Products', 'catalog', 'Read product details, prices, and catalog status'),
    ('products.write', 'Manage Products', 'catalog', 'Create, update, and toggle active status of products'),
    ('orders.read', 'View Orders', 'orders', 'View order list, financial breakdowns, and customer notes'),
    ('orders.write', 'Fulfill Orders', 'orders', 'Update order statuses, assign courier partners, and tracking IDs'),
    ('customers.read', 'View Customers', 'customers', 'Access customer directory and order history'),
    ('customers.write', 'Manage Customers', 'customers', 'Update customer profile status and notes'),
    ('inventory.read', 'View Inventory', 'inventory', 'View warehouse stock counts and low stock warnings'),
    ('inventory.write', 'Adjust Inventory', 'inventory', 'Perform stock adjustments and audit stock movements'),
    ('payments.read', 'View Payments', 'payments', 'View payment gateway status, mode, and masked credentials'),
    ('payments.write', 'Manage Payments', 'payments', 'Update payment gateway credentials and webhook secrets'),
    ('shipping.write', 'Manage Shipping', 'shipping', 'Assign logistics partners and generate thermal shipping labels'),
    ('reports.read', 'View Reports', 'reports', 'Generate business analytics, GST reports, and export sales CSV'),
    ('settings.write', 'Manage Settings', 'settings', 'Configure store branding, delivery charges, and GST policy'),
    ('users.write', 'Manage Admin Users', 'admin', 'Add, modify, and disable secondary administrator accounts'),
    ('backup.manage', 'Backup & Restore', 'system', 'Export database snapshots and perform store restoration'),
    ('activity.read', 'View Audit Logs', 'security', 'View security audit trail and system access logs')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.role_permissions (role_id, permission_id)
SELECT 'main_admin', id FROM public.permissions
ON CONFLICT DO NOTHING;

INSERT INTO public.role_permissions (role_id, permission_id)
VALUES
    ('admin', 'products.read'),
    ('admin', 'products.write'),
    ('admin', 'orders.read'),
    ('admin', 'orders.write'),
    ('admin', 'customers.read'),
    ('admin', 'inventory.read'),
    ('admin', 'inventory.write'),
    ('admin', 'payments.read'),
    ('admin', 'shipping.write'),
    ('admin', 'reports.read'),
    ('admin', 'settings.write'),
    ('admin', 'activity.read')
ON CONFLICT DO NOTHING;

INSERT INTO public.admin_users (id, email, mobile, full_name, role, status)
VALUES (
    'admin_infostors24_main',
    'infostors24@gmail.com',
    '8695222581',
    'INFOSTORS Main Administrator',
    'main_admin',
    'active'
) ON CONFLICT (email) DO UPDATE SET
    role = 'main_admin',
    status = 'active';

INSERT INTO public.store_settings (
    id,
    store_name,
    tagline,
    logo_url,
    header_logo_height,
    helpline,
    email,
    office_address,
    standard_delivery_charge,
    free_delivery_min,
    enable_free_delivery_threshold,
    announcement,
    whatsapp_url,
    instagram_url,
    facebook_url,
    youtube_url,
    return_window,
    business_legal_name,
    trade_name,
    owner_name,
    pan,
    gst_enabled,
    gstin,
    gst_percentage,
    gst_type,
    gst_state,
    show_gstin_on_invoice,
    allow_customer_b2b_gst
) VALUES (
    'default',
    'INFOSTORS',
    'Smart Gadgets | Better Life',
    '',
    72,
    '+91 94778 39200 (Toll Free / WhatsApp)',
    'contactinfostors@gmail.com',
    'INFOSTORS Headquarters, Garia station road, Kolkata 700084, India',
    49.00,
    499.00,
    true,
    'Free Delivery on all orders above ₹499 across India',
    'https://wa.me/919477839200',
    'https://www.instagram.com/infostors',
    'https://www.facebook.com/Infostors',
    'https://www.youtube.com/@InfoStors',
    '7 Days Replacement Guarantee',
    'INFOSTORS ENTERPRISES PRIVATE LIMITED',
    'INFOSTORS',
    'InfoStors Management',
    'AAACI1234F',
    false,
    '19AAACI1234F1Z8',
    18.00,
    'inclusive',
    '19 - West Bengal',
    true,
    true
) ON CONFLICT (id) DO NOTHING;

INSERT INTO public.categories (id, name, emoji, description, display_order)
VALUES 
    ('all', 'All Categories', '🛍️', 'Explore our entire curated selection of smart products', 0),
    ('electronics', 'Electronics', '⚡', 'Smart electronics, power hubs, and digital lifestyle essentials', 1),
    ('smart-home', 'Smart Home', '🏠', 'Automate your living spaces with sensors, smart sockets, and monitors', 2),
    ('mobile-accessories', 'Mobile Accessories', '📱', 'Fast chargers, magnetic power banks, car mounts & tough cables', 3),
    ('audio-sound', 'Audio & Sound', '🔊', 'True wireless earbuds, soundbars and portable party speakers', 4),
    ('home-kitchen', 'Home & Kitchen', '🍳', 'Modern cookware, precision blenders, and smart kitchen helpers', 5),
    ('massagers', 'Massagers', '💆', 'Deep tissue massage guns, neck massagers, and relaxation devices', 6),
    ('rgb-lights', 'RGB Lights', '🌈', 'Smart ambient light bars, neon strips, and sound-reactive lamps', 7)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.products (
    id, name, category_id, brand, price, original_price, image_url, gallery_images, 
    short_description, description, features, stock, rating, reviews_count, 
    is_trending, is_bestseller, is_new_arrival, is_deal, badge
) VALUES 
    (
        'inf-101',
        'AeroBeat Pro ANC Wireless Earbuds with 40h Playtime',
        'audio-sound',
        'INFOSTORS SoundLab',
        1899.00,
        4499.00,
        'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
        '["https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80","https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?w=800&auto=format&fit=crop&q=80"]'::jsonb,
        'Active Noise Cancellation (ANC), 10mm titanium bass drivers, fast Type-C charging.',
        'Immerse in studio-grade audio with our flagship wireless earbuds. Features hybrid Active Noise Cancellation up to 32dB, quad-microphone crystal clear calling, IPX5 sweat resistance, and instant Bluetooth 5.3 auto-pairing.',
        '["32dB Hybrid Active Noise Cancellation with Transparency Mode","Quad-Mic AI ENC for crystal clear phone and video calls","Up to 40 Hours combined playtime","10-minute ASAP charge delivers 120 minutes of music","IPX5 water and sweat resistant rating"]'::jsonb,
        42,
        4.80,
        1420,
        true,
        true,
        false,
        true,
        'BESTSELLER'
    ),
    (
        'inf-102',
        'VoltCharge 65W GaN Dual Type-C Ultra-Compact Fast Charger',
        'mobile-accessories',
        'INFOSTORS Power',
        1499.00,
        2999.00,
        'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=800&auto=format&fit=crop&q=80',
        '["https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=800&auto=format&fit=crop&q=80"]'::jsonb,
        'Next-gen Gallium Nitride (GaN III) technology for laptops, iPhones, and Android devices.',
        'Powers your laptops, smartphones, and tablets simultaneously. Built with aerospace-grade GaN technology for maximum efficiency, cool operation, and multi-protocol fast charging support (PD 3.0, QC 4.0, PPS).',
        '["65W Max Output power charges MacBooks, laptops and fast charge phones","Dual USB Type-C + 1 USB-A smart triple port output","GaN III semiconductor ensures 45% smaller form factor","Intelligent multi-layer protection against short-circuit and over-voltage"]'::jsonb,
        55,
        4.90,
        960,
        true,
        false,
        true,
        false,
        'TOP TECH'
    ),
    (
        'inf-103',
        'LumiSync Flow RGB Smart Light Bar with Music Reactive Mode',
        'rgb-lights',
        'INFOSTORS Living',
        1299.00,
        2499.00,
        'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80',
        '["https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80"]'::jsonb,
        'Immersive ambient lighting for gaming setups, desk setups, and TV backdrops.',
        'Elevate your desk setup or home theater. Equipped with high-sensitivity sound sensors that pulse dynamically to music beats, gaming sound effects, or movie dialogue. Controlled via companion mobile app or physical touch base.',
        '["16 Million RGB Colors with 32 vibrant dynamic preset lighting effects","Built-in ultra-sensitive acoustic microphone for sound rhythm syncing","Horizontal or vertical dual orientation with included aluminum stand","Universal 5V USB powered for computer desks, consoles or TV ports"]'::jsonb,
        34,
        4.70,
        710,
        false,
        false,
        true,
        true,
        'TRENDING'
    )
ON CONFLICT (id) DO NOTHING;
-- INFOSTORS production server bridge. Non-destructive.
-- Adds only fields/tables required by the secure Node API.
ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS password_hash TEXT;
ALTER TABLE public.admin_users ADD COLUMN IF NOT EXISTS password_hash TEXT;

CREATE TABLE IF NOT EXISTS public.password_resets (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_password_resets_customer ON public.password_resets(customer_id);
CREATE INDEX IF NOT EXISTS idx_password_resets_token ON public.password_resets(token_hash);

CREATE TABLE IF NOT EXISTS public.webhook_events (
  event_id TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.payment_audit_logs (
  id TEXT PRIMARY KEY,
  admin_email TEXT NOT NULL,
  action TEXT NOT NULL,
  mode TEXT NOT NULL CHECK (mode IN ('test','live')),
  success BOOLEAN NOT NULL,
  timestamp TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION public.increment_customer_stats(
  p_customer_id TEXT,
  p_order_total NUMERIC
) RETURNS VOID
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.customers
  SET total_orders = total_orders + 1,
      total_spent = total_spent + COALESCE(p_order_total,0),
      updated_at = now()
  WHERE id = p_customer_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.adjust_inventory(
  p_product_id TEXT,
  p_value INTEGER,
  p_is_exact BOOLEAN DEFAULT false,
  p_reason TEXT DEFAULT 'admin_adjustment',
  p_created_by TEXT DEFAULT 'admin'
) RETURNS public.products
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  p public.products;
  new_stock INTEGER;
  old_stock INTEGER;
BEGIN
  SELECT * INTO p FROM public.products WHERE id = p_product_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Product % not found', p_product_id; END IF;
  old_stock := p.stock;
  new_stock := CASE WHEN p_is_exact THEN GREATEST(0,p_value) ELSE GREATEST(0,p.stock+p_value) END;
  UPDATE public.products SET stock=new_stock, updated_at=now() WHERE id=p_product_id RETURNING * INTO p;
  INSERT INTO public.inventory_logs(product_id,change_amount,previous_stock,new_stock,reason,created_by,notes)
  VALUES(p_product_id,new_stock-old_stock,old_stock,new_stock,'admin_adjustment',p_created_by,'Administrative stock adjustment');
  RETURN p;
END;
$$;

-- Server uses service_role and therefore does not expose these tables to anonymous clients.
ALTER TABLE public.password_resets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.webhook_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_audit_logs ENABLE ROW LEVEL SECURITY;
