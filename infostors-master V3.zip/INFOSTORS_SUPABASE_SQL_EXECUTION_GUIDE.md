# INFOSTORS — SUPABASE SQL EXECUTION & VERIFICATION GUIDE

**Project ID:** `oewerfftzqklptdsdfrm`  
**Project URL:** `https://oewerfftzqklptdsdfrm.supabase.co`  
**SQL Target:** PostgreSQL 15+  

---

## 1. PRE-EXECUTION CHECKLIST

1. Log into your Supabase Dashboard at [https://supabase.com/dashboard](https://supabase.com/dashboard).
2. Select your project: **`oewerfftzqklptdsdfrm`**.
3. In the left-hand navigation sidebar, click on **SQL Editor**.

---

## 2. EXECUTION METHOD OPTIONS

### Option A: Master Single-Script Execution (Recommended)
This runs the entire schema, triggers, RLS, storage buckets, and seed data in one idempotent pass:
1. Open the file `INFOSTORS_FINAL_SUPABASE_ALL_IN_ONE.sql`.
2. Copy the entire file content.
3. In the Supabase SQL Editor, click **"+ New Query"**.
4. Paste the content into the editor window.
5. Click **"Run"** (or press `Ctrl+Enter` / `Cmd+Enter`).
6. Confirm the console displays: `Success. No rows returned`.

---

### Option B: Step-by-Step Multi-Migration Execution
If you prefer running individual modular migrations via Supabase CLI or the SQL Editor, execute the files in `INFOSTORS_FINAL_SUPABASE_MIGRATIONS/` in this exact sequence:

1. `01_extensions.sql`: Enables `uuid-ossp` and `pgcrypto`.
2. `02_types.sql`: Registers custom PostgreSQL enum types.
3. `03_tables.sql`: Creates all 18 core relational tables.
4. `04_constraints.sql`: Applies Indian mobile format checks, pincode regex, and stock bounds.
5. `05_indexes.sql`: Adds performance indexes for catalog, order lookups, and audit queries.
6. `06_functions.sql`: Installs `set_updated_at`, monotonic `generate_order_id`, and stock decrement logic.
7. `07_triggers.sql`: Hooks automated timestamp updates and inventory audit logs.
8. `08_rls.sql`: Enables RLS and binds strict customer isolation and admin RBAC policies.
9. `09_storage.sql`: Configures the 4 storage buckets (`product-images`, `store-assets`, `invoices`, `shipping-labels`) and storage policies.
10. `10_seed.sql`: Populates default roles, permissions, Main Admin account (`infostors24@gmail.com`), store settings, and catalog items.

---

## 3. POST-EXECUTION VERIFICATION QUERIES

Run these validation queries in the Supabase SQL Editor to confirm that all objects were created successfully:

### 1. Verify All 18 Tables Exist
```sql
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;
```
*Expected Result:* `admin_users`, `audit_logs`, `categories`, `customer_addresses`, `customer_carts`, `customer_messages`, `customer_wishlists`, `customers`, `delete_requests`, `inventory_logs`, `notifications`, `order_items`, `order_status_history`, `orders`, `payment_settings`, `permissions`, `products`, `role_permissions`, `roles`, `store_settings`.

### 2. Verify Row Level Security is Enabled on All Tables
```sql
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY tablename;
```
*Expected Result:* `rowsecurity = true` for every single table.

### 3. Verify Stored Functions
```sql
SELECT routine_name 
FROM information_schema.routines 
WHERE routine_schema = 'public'
ORDER BY routine_name;
```
*Expected Result:* `deduct_inventory_for_order_item`, `generate_order_id`, `has_permission`, `is_admin`, `is_main_admin`, `record_order_status_change`, `set_updated_at`.

### 4. Verify Monotonic Order ID Generator
```sql
SELECT public.generate_order_id() AS sample_order_id;
```
*Expected Result:* Returns `INF-YYYYMMDD-0001` (e.g. `INF-20260926-0001`).

### 5. Verify Storage Buckets
```sql
SELECT id, name, public, file_size_limit 
FROM storage.buckets 
ORDER BY id;
```
*Expected Result:*
- `invoices` (public: false)
- `product-images` (public: true)
- `shipping-labels` (public: false)
- `store-assets` (public: true)

### 6. Verify Seed Data
```sql
SELECT count(*) AS roles_count FROM public.roles;
SELECT count(*) AS permissions_count FROM public.permissions;
SELECT count(*) AS categories_count FROM public.categories;
SELECT count(*) AS products_count FROM public.products;
SELECT store_name, helpline FROM public.store_settings WHERE id = 'default';
```
*Expected Result:*
- `roles_count`: 3 (`main_admin`, `admin`, `support`)
- `permissions_count`: 16
- `categories_count`: 8
- `products_count`: 3+
- `store_name`: `'INFOSTORS'`
