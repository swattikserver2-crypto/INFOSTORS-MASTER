/**
 * INFOSTORS Email Service
 * Handles transactional emails, password resets, and notifications.
 */

export interface PasswordResetEmailOptions {
  to: string;
  customerName: string;
  resetLink: string;
  expiresInMinutes: number;
}

export async function sendPasswordResetEmail(options: PasswordResetEmailOptions): Promise<{ success: boolean; messageId?: string }> {
  console.log(`[INFOSTORS Email] Sending password reset to ${options.to}`);
  console.log(`[INFOSTORS Email] Reset Link: ${options.resetLink} (Expires in ${options.expiresInMinutes} mins)`);
  
  // In development and production fallback without external SMTP credentials, log securely
  return {
    success: true,
    messageId: `sim_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
  };
}
