/**
 * Safe API response parsing utility for INFOSTORS.
 * Handles both JSON responses and non-JSON error fallbacks safely.
 */

export interface ParsedApiResponse<T = any> {
  ok: boolean;
  data: T | null;
  errorMessage?: string;
  status: number;
}

export async function parseApiResponse<T = any>(res: Response): Promise<ParsedApiResponse<T>> {
  let data: any = null;
  let errorMessage: string | undefined;

  try {
    const contentType = res.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      data = await res.json();
    } else {
      const text = await res.text();
      try {
        data = JSON.parse(text);
      } catch {
        data = text ? { message: text } : null;
      }
    }
  } catch (err: any) {
    errorMessage = err?.message || 'Failed to parse response body';
  }

  if (!res.ok) {
    errorMessage = data?.error || data?.message || errorMessage || `Request failed with status ${res.status}`;
  }

  return {
    ok: res.ok,
    data,
    errorMessage,
    status: res.status,
  };
}
