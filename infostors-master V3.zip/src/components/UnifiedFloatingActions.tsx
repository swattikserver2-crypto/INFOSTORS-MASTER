import React from 'react';
import { MessageCircle, Download } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const UnifiedFloatingActions: React.FC = () => {
  const { storeSettings } = useShop();

  const handleWhatsAppClick = () => {
    const phone = storeSettings.helpline?.replace(/[^0-9]/g, '') || '919477839200';
    const text = encodeURIComponent('Hi INFOSTORS Support! I have an inquiry regarding your products and orders.');
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-40 flex flex-col items-end gap-2.5">
      {/* WhatsApp Help Float */}
      <button
        onClick={handleWhatsAppClick}
        className="w-12 h-12 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30 transition-all hover:scale-110 active:scale-95 cursor-pointer"
        title="Chat on WhatsApp"
        aria-label="WhatsApp Support"
      >
        <MessageCircle className="w-6 h-6 fill-white" />
      </button>
    </div>
  );
};
