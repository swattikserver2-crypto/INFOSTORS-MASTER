import React from 'react';
import { X, ShieldCheck, FileText, RotateCcw, Truck } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const PolicyModal: React.FC = () => {
  const { policyModal, setPolicyModal, storeSettings } = useShop();

  if (!policyModal) return null;

  const getPolicyContent = () => {
    switch (policyModal) {
      case 'privacy':
        return {
          title: 'Privacy Policy',
          icon: <ShieldCheck className="w-5 h-5 text-blue-500" />,
          content: (
            <div className="space-y-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <p>
                At <strong>{storeSettings.storeName || 'INFOSTORS'}</strong>, we prioritize the protection and confidentiality of your personal information.
              </p>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm">Information Collection</h4>
              <p>
                We only collect data necessary to fulfill your orders, process payments securely, coordinate logistics deliveries, and provide customer support.
              </p>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm">Data Protection</h4>
              <p>
                Customer passwords and sensitive credentials are encrypted using industry-standard hashing algorithms (bcrypt/AES-256). We never sell or rent your personal information to third parties.
              </p>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm">Contact Information</h4>
              <p>
                For privacy inquiries: {storeSettings.email || 'contactinfostors@gmail.com'}
              </p>
            </div>
          ),
        };
      case 'terms':
        return {
          title: 'Terms of Service',
          icon: <FileText className="w-5 h-5 text-indigo-500" />,
          content: (
            <div className="space-y-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <p>
                Welcome to <strong>{storeSettings.storeName || 'INFOSTORS'}</strong>. By accessing or using our platform, you agree to comply with our terms.
              </p>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm">Orders & Pricing</h4>
              <p>
                All prices listed are in Indian Rupees (INR) inclusive of applicable taxes unless specified otherwise. We reserve the right to correct typographical pricing errors.
              </p>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm">Shipping & Delivery</h4>
              <p>
                Standard delivery timeframe is 3-7 business days across India. Orders above ₹{storeSettings.freeDeliveryMin || 499} qualify for free standard delivery.
              </p>
            </div>
          ),
        };
      case 'returns':
      default:
        return {
          title: 'Return & Replacement Policy',
          icon: <RotateCcw className="w-5 h-5 text-emerald-500" />,
          content: (
            <div className="space-y-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <p>
                We offer a <strong>{storeSettings.returnWindow || '7 Days Replacement Guarantee'}</strong> on all verified products for defects or damaged-in-transit packages.
              </p>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm">Eligibility for Replacement</h4>
              <ul className="list-disc pl-5 space-y-1">
                <li>Item must be reported within 7 days of delivery.</li>
                <li>Product must be in original condition with original box, accessories, and tags intact.</li>
                <li>Physical damage or water damage caused by misuse is not eligible.</li>
              </ul>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm">Helpline & Support</h4>
              <p>
                Reach our customer assistance team directly at: {storeSettings.helpline || '+91 94778 39200'}.
              </p>
            </div>
          ),
        };
    }
  };

  const { title, icon, content } = getPolicyContent();

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[85vh]">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            {icon}
            <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">{title}</h3>
          </div>
          <button
            onClick={() => setPolicyModal(null)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1">{content}</div>

        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 text-right shrink-0">
          <button
            onClick={() => setPolicyModal(null)}
            className="px-5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold text-xs hover:opacity-90 transition-opacity cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
