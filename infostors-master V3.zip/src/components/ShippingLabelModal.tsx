import React, { useState, useEffect, useMemo } from 'react';
import { X, Printer, Truck, MapPin, Phone, Package, Check, RefreshCw, Barcode, QrCode } from 'lucide-react';
import { Order, StoreSettings } from '../types';
import bwipjs from 'bwip-js';
import QRCode from 'qrcode';

interface ShippingLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  storeSettings: StoreSettings;
  onOrderUpdated?: (orderId: string, updates: { courierPartner?: string; trackingId?: string }) => void;
}

export const ShippingLabelModal: React.FC<ShippingLabelModalProps> = ({
  isOpen,
  onClose,
  order,
  storeSettings,
  onOrderUpdated,
}) => {
  if (!isOpen || !order) return null;

  // Active tracking / AWB number from database or authoritative order identifier
  const awbNumber = useMemo(() => {
    if (order.trackingId && order.trackingId.trim().length > 0) {
      return order.trackingId.trim();
    }
    const cleanNum = (order.orderId || '').replace(/\D/g, '');
    return `INF${cleanNum || '700084'}`;
  }, [order.trackingId, order.orderId]);

  const courierName = order.courierPartner || 'Delhivery Express';
  const customerPin = order.customer?.pincode || '700084';
  const isCod = order.paymentMethod === 'cod';
  const collectableAmount = isCod ? (order.totalAmount || 0) : 0;

  // 1. Generate real Code 128 Barcode as high-resolution SVG
  const barcodeSvg = useMemo(() => {
    try {
      return bwipjs.toSVG({
        bcid: 'code128',
        text: awbNumber,
        scale: 2,
        height: 12,
        includetext: true,
        textxalign: 'center',
      });
    } catch (err) {
      console.error('Code 128 barcode generation error:', err);
      return '';
    }
  }, [awbNumber]);

  // 2. Generate real ISO/IEC 16022 Data Matrix barcode as crisp SVG
  const dataMatrixSvg = useMemo(() => {
    try {
      const dmPayload = `${order.orderId}|${awbNumber}|${customerPin}|${isCod ? 'COD' : 'PRE'}|${order.totalAmount || 0}`;
      return bwipjs.toSVG({
        bcid: 'datamatrix',
        text: dmPayload,
        scale: 3,
        paddingwidth: 1,
        paddingheight: 1,
      });
    } catch (err) {
      console.error('Data Matrix generation error:', err);
      return '';
    }
  }, [order.orderId, awbNumber, customerPin, isCod, order.totalAmount]);

  // 3. Generate real ISO/IEC 18004 QR Code as high-contrast SVG
  const [qrCodeSvg, setQrCodeSvg] = useState<string>('');

  useEffect(() => {
    let isMounted = true;
    const qrPayload = `https://infostors.com/track?order=${encodeURIComponent(order.orderId)}&awb=${encodeURIComponent(awbNumber)}&pin=${encodeURIComponent(customerPin)}`;

    QRCode.toString(qrPayload, {
      type: 'svg',
      margin: 1,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    })
      .then((svg) => {
        if (isMounted) setQrCodeSvg(svg);
      })
      .catch((err) => {
        console.error('QR code generation error:', err);
      });

    return () => {
      isMounted = false;
    };
  }, [order.orderId, awbNumber, customerPin]);

  const handlePrint = () => {
    // Ensure document body does not have printing-invoice class to isolate thermal label
    document.body.classList.remove('printing-invoice');
    window.print();
  };

  const pickupLocation = storeSettings.shippingLabelSettings?.pickupLocation;
  const returnCompany = pickupLocation?.companyName || storeSettings.businessLegalName || storeSettings.storeName || 'INFOSTORS';
  const returnAddress = pickupLocation?.address || storeSettings.officeAddress || 'INFOSTORS Return Hub, Kolkata 700084, India';
  const returnPhone = pickupLocation?.contactNumber || storeSettings.helpline || '+91 94778 39200';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white text-slate-900 w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Control Bar (Hidden on print) */}
        <div className="px-5 py-3 bg-slate-900 text-white flex items-center justify-between print:hidden shrink-0">
          <div className="flex items-center gap-2">
            <Printer className="w-4 h-4 text-blue-400" />
            <div>
              <h3 className="font-bold text-xs">4×6" Thermal Shipping Label</h3>
              <p className="text-[10px] text-slate-400">Code 128 Barcode + QR Code + Data Matrix</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
              id="btn-print-shipping-label"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Label (4×6)</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Container for Preview */}
        <div className="p-4 sm:p-6 overflow-y-auto flex justify-center bg-slate-100/70">
          {/* Printable Thermal Label (4in x 6in isolation target) */}
          <div
            id="shipping-label-printable"
            className="w-full max-w-[384px] bg-white text-black border-2 border-black p-3.5 space-y-2 text-[11px] leading-tight font-sans shadow-lg select-text"
          >
            {/* 1. Header: Brand + Order Manifest */}
            <div className="border-b-2 border-black pb-2 flex justify-between items-start gap-2">
              <div>
                {storeSettings.logoUrl ? (
                  <img
                    src={storeSettings.logoUrl}
                    alt={storeSettings.storeName || 'INFOSTORS'}
                    className="h-9 max-w-[130px] object-contain mb-0.5 filter grayscale contrast-200"
                  />
                ) : (
                  <h2 className="font-black text-lg tracking-tight leading-none">
                    {storeSettings.storeName || 'INFOSTORS'}
                  </h2>
                )}
                <p className="text-[9px] uppercase font-bold text-black tracking-wider mt-0.5">
                  Surface / Air Express Logistics
                </p>
              </div>
              <div className="text-right">
                <p className="font-mono font-black text-xs">{order.orderId}</p>
                <p className="text-[9px] font-bold text-black">
                  {new Date(order.date).toLocaleDateString('en-IN', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                  })}
                </p>
                <span className="inline-block px-1.5 py-0.5 mt-0.5 bg-black text-white font-mono font-extrabold text-[8px] uppercase rounded-xs">
                  {isCod ? 'COD' : 'PREPAID'}
                </span>
              </div>
            </div>

            {/* 2. Routing Box: Courier Partner + Destination Pincode */}
            <div className="border border-black p-2 flex justify-between items-center bg-white">
              <div>
                <span className="text-[8px] uppercase font-bold text-black tracking-wider block">Logistics Partner</span>
                <p className="font-black text-xs text-black">{courierName}</p>
                <span className="text-[8px] font-mono font-bold text-black">AWB: {awbNumber}</span>
              </div>
              <div className="text-right">
                <span className="text-[8px] uppercase font-bold text-black tracking-wider block">Routing PIN Code</span>
                <div className="border-2 border-black px-2 py-0.5 inline-block font-mono font-black text-base text-black bg-white">
                  {customerPin}
                </div>
              </div>
            </div>

            {/* 3. Primary Barcode: Code 128 AWB */}
            <div className="border border-black p-2 text-center bg-white flex flex-col items-center justify-center">
              {barcodeSvg ? (
                <div
                  className="w-full flex justify-center [&_svg]:max-w-full [&_svg]:h-[46px] [&_svg]:w-auto"
                  dangerouslySetInnerHTML={{ __html: barcodeSvg }}
                />
              ) : (
                <div className="font-mono font-bold text-sm tracking-widest">{awbNumber}</div>
              )}
            </div>

            {/* 4. Dual 2D Matrix Section: Logistics QR Code + Industrial Data Matrix */}
            <div className="grid grid-cols-2 gap-2 border border-black p-2 bg-white">
              {/* Left: ISO/IEC 18004 QR Code */}
              <div className="flex flex-col items-center text-center border-r border-black pr-2">
                <div className="text-[8px] uppercase font-black tracking-wider mb-1 flex items-center gap-1">
                  <QrCode className="w-2.5 h-2.5" />
                  <span>Logistics QR Code</span>
                </div>
                {qrCodeSvg ? (
                  <div
                    className="w-20 h-20 flex items-center justify-center [&_svg]:w-full [&_svg]:h-full"
                    dangerouslySetInnerHTML={{ __html: qrCodeSvg }}
                  />
                ) : (
                  <div className="w-20 h-20 border border-dashed border-black flex items-center justify-center text-[8px]">
                    QR Loading
                  </div>
                )}
                <span className="text-[7.5px] font-mono font-bold text-black mt-0.5">SCAN FOR TRACKING</span>
              </div>

              {/* Right: ISO/IEC 16022 Data Matrix */}
              <div className="flex flex-col items-center text-center pl-1">
                <div className="text-[8px] uppercase font-black tracking-wider mb-1 flex items-center gap-1">
                  <Barcode className="w-2.5 h-2.5" />
                  <span>2D Data Matrix</span>
                </div>
                {dataMatrixSvg ? (
                  <div
                    className="w-20 h-20 flex items-center justify-center [&_svg]:w-full [&_svg]:h-full"
                    dangerouslySetInnerHTML={{ __html: dataMatrixSvg }}
                  />
                ) : (
                  <div className="w-20 h-20 border border-dashed border-black flex items-center justify-center text-[8px]">
                    DM Loading
                  </div>
                )}
                <span className="text-[7.5px] font-mono font-bold text-black mt-0.5">ISO/IEC 16022 MANIFEST</span>
              </div>
            </div>

            {/* 5. Ship To (Recipient Information) */}
            <div className="border-2 border-black p-2.5 space-y-0.5 bg-white">
              <span className="text-[8px] font-black uppercase tracking-wider block border-b border-black pb-0.5">
                Ship To (Recipient)
              </span>
              <p className="font-black text-sm text-black pt-0.5">{order.customer?.fullName}</p>
              <p className="font-semibold text-black text-[10px] leading-snug">{order.customer?.address}</p>
              <p className="font-black text-xs text-black">
                {order.customer?.city}, {order.customer?.state} - <span className="underline">{customerPin}</span>
              </p>
              <p className="font-black text-black pt-0.5 text-[11px]">
                Mobile: +91 {order.customer?.phone}
              </p>
              {order.customer?.email && (
                <p className="text-[9px] text-black">Email: {order.customer?.email}</p>
              )}
            </div>

            {/* 6. Payment & Collectable Box */}
            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div className="border border-black p-2">
                <span className="text-[8px] uppercase font-bold block">Payment Mode</span>
                <p className="font-black text-xs uppercase mt-0.5">
                  {isCod ? 'Cash on Delivery (COD)' : 'Prepaid Online'}
                </p>
              </div>
              <div className="border-2 border-black p-2 text-right bg-black text-white">
                <span className="text-[8px] uppercase font-bold block opacity-90">Collectable Amount</span>
                <p className="font-black text-sm mt-0.5">
                  {isCod ? `₹${collectableAmount.toLocaleString('en-IN')}` : '₹0.00 (PAID)'}
                </p>
              </div>
            </div>

            {/* 7. Item Reference List */}
            {order.items && order.items.length > 0 && (
              <div className="border border-black p-1.5 bg-white">
                <div className="flex justify-between text-[8px] font-black uppercase border-b border-black pb-0.5 mb-1">
                  <span>Item / Description</span>
                  <span>Qty</span>
                </div>
                <div className="space-y-0.5 max-h-14 overflow-hidden">
                  {order.items.slice(0, 3).map((item, idx) => {
                    const itemName = (item as any).name || item.product?.name || (item as any).productId || item.product?.id || 'Product Item';
                    return (
                      <div key={idx} className="flex justify-between text-[9px] font-semibold">
                        <span className="truncate max-w-[240px]">
                          {itemName}
                        </span>
                        <span className="font-mono font-bold">x{item.quantity}</span>
                      </div>
                    );
                  })}
                  {order.items.length > 3 && (
                    <p className="text-[8px] italic text-black">+ {order.items.length - 3} more items</p>
                  )}
                </div>
              </div>
            )}

            {/* 8. Shipper Return Address */}
            <div className="border-t-2 border-dashed border-black pt-1.5 text-[8.5px] leading-tight text-black">
              <p className="font-black uppercase">If undelivered, return to:</p>
              <p className="font-bold">{returnCompany}</p>
              <p>{returnAddress}</p>
              <p className="font-semibold">Helpline: {returnPhone}</p>
            </div>

            {/* 9. Footer Specification */}
            <div className="border-t border-black pt-1 flex justify-between text-[7.5px] font-mono text-black">
              <span>Standard 4×6 Direct Thermal Courier Format</span>
              <span>Weight: 0.50 KG (Approx)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
