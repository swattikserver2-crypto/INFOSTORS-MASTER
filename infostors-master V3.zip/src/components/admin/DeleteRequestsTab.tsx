import React, { useState, useEffect } from 'react';
import { Trash2, AlertCircle, CheckCircle2, XCircle, ShieldAlert } from 'lucide-react';
import { DeleteRequest } from '../../types';
import { parseApiResponse } from '../../utils/safeApi';

interface DeleteRequestsTabProps {
  adminProfile: any;
  adminToken: string;
  onRefreshOrders: () => void;
  onRefreshCustomers: () => void;
}

export const DeleteRequestsTab: React.FC<DeleteRequestsTabProps> = ({
  adminProfile,
  adminToken,
  onRefreshOrders,
  onRefreshCustomers,
}) => {
  const [requests, setRequests] = useState<DeleteRequest[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (adminToken) {
      setLoading(true);
      fetch('/api/admin/delete-requests', {
        headers: { Authorization: `Bearer ${adminToken}` },
      })
        .then(res => parseApiResponse(res))
        .then(res => {
          if (res.ok && res.data?.requests) {
            setRequests(res.data.requests);
          }
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  }, [adminToken]);

  return (
    <div className="space-y-5 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-600" />
            <span>Multi-Party Safe Deletion Workflow (Two-Man Rule)</span>
          </h3>
          <p className="text-[11px] text-slate-400">
            Destructive deletions of orders or customers require explicit authorization by the Main Administrator
          </p>
        </div>
      </div>

      {loading ? (
        <div className="py-12 text-center text-slate-400">Loading requests...</div>
      ) : requests.length === 0 ? (
        <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 text-center space-y-2">
          <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
          <p className="font-bold text-slate-800 dark:text-slate-200">No Pending Deletion Requests</p>
          <p className="text-[11px] text-slate-400">All customer records and order documents are in sync.</p>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
          {requests.map(req => (
            <div key={req.id} className="p-4 flex items-center justify-between">
              <div>
                <p className="font-bold text-slate-900 dark:text-white">{req.targetSummary}</p>
                <p className="text-[11px] text-slate-400">Reason: {req.reason}</p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-amber-100 text-amber-800">
                {req.status}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
