import React, { useState } from 'react';
import { Package, Search, Plus, Minus, Save, AlertTriangle, ArrowRight } from 'lucide-react';
import { Product } from '../../types';

interface AdminInventoryTabProps {
  products: Product[];
  updateProduct: (product: Product) => void;
  onNavigateProducts: () => void;
}

export const AdminInventoryTab: React.FC<AdminInventoryTabProps> = ({
  products,
  updateProduct,
  onNavigateProducts,
}) => {
  const [search, setSearch] = useState('');
  const [stockChanges, setStockChanges] = useState<Record<string, number>>({});

  const filtered = products.filter(
    p => p.name.toLowerCase().includes(search.toLowerCase()) || p.category.toLowerCase().includes(search.toLowerCase())
  );

  const handleAdjust = (id: string, delta: number) => {
    const current = stockChanges[id] ?? (products.find(p => p.id === id)?.stock ?? 0);
    const updated = Math.max(0, current + delta);
    setStockChanges(prev => ({ ...prev, [id]: updated }));
  };

  const handleSave = (product: Product) => {
    const newStock = stockChanges[product.id];
    if (newStock !== undefined) {
      updateProduct({ ...product, stock: newStock });
      const nextChanges = { ...stockChanges };
      delete nextChanges[product.id];
      setStockChanges(nextChanges);
    }
  };

  return (
    <div className="space-y-4 text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search inventory by product name or category..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-blue-500"
          />
        </div>

        <button
          onClick={onNavigateProducts}
          className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
        >
          <span>Catalog Management</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="grid grid-cols-12 px-4 py-3 bg-slate-50 dark:bg-slate-800/80 font-bold text-slate-500 text-[11px] uppercase tracking-wider">
          <div className="col-span-6 sm:col-span-5">Product</div>
          <div className="hidden sm:block sm:col-span-3">Category</div>
          <div className="col-span-3 sm:col-span-2 text-center">Stock Level</div>
          <div className="col-span-3 sm:col-span-2 text-right">Actions</div>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {filtered.map(product => {
            const currentStock = stockChanges[product.id] ?? (product.stock || 0);
            const hasChanged = stockChanges[product.id] !== undefined;

            return (
              <div key={product.id} className="grid grid-cols-12 px-4 py-3 items-center hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <div className="col-span-6 sm:col-span-5 flex items-center gap-3 min-w-0">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-10 h-10 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="font-bold text-slate-900 dark:text-white truncate">{product.name}</p>
                    <span className="text-[10px] text-slate-400 font-mono">₹{product.price}</span>
                  </div>
                </div>

                <div className="hidden sm:block sm:col-span-3 text-slate-500 capitalize">
                  {product.category}
                </div>

                <div className="col-span-3 sm:col-span-2 flex items-center justify-center gap-2">
                  <button
                    onClick={() => handleAdjust(product.id, -1)}
                    className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold cursor-pointer"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span
                    className={`font-mono font-extrabold w-8 text-center ${
                      currentStock <= 5 ? 'text-rose-600' : 'text-slate-900 dark:text-white'
                    }`}
                  >
                    {currentStock}
                  </span>
                  <button
                    onClick={() => handleAdjust(product.id, 1)}
                    className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="col-span-3 sm:col-span-2 text-right">
                  {hasChanged ? (
                    <button
                      onClick={() => handleSave(product)}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-[11px] inline-flex items-center gap-1 shadow-xs cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>Save</span>
                    </button>
                  ) : (
                    <span className="text-[11px] text-slate-400">Synced</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
