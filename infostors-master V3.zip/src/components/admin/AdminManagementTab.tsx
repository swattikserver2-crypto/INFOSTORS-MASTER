import React, { useState, useEffect } from 'react';
import { Users, Shield, Plus, Trash2, CheckCircle2, Lock } from 'lucide-react';
import { AdminUser, AdminRole } from '../../types';
import { parseApiResponse } from '../../utils/safeApi';

export const AdminManagementTab: React.FC = () => {
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [newMobile, setNewMobile] = useState('');
  const [newRole, setNewRole] = useState<AdminRole>('admin');

  useEffect(() => {
    const token = localStorage.getItem('infostors_admin_token') || '';
    if (token) {
      setLoading(true);
      fetch('/api/admin/admins', {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then(res => parseApiResponse(res))
        .then(res => {
          if (res.ok && res.data?.admins) {
            setAdmins(res.data.admins);
          }
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  }, []);

  return (
    <div className="space-y-6 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-600" />
            <span>Administrator Access & Role Management</span>
          </h3>
          <p className="text-[11px] text-slate-400">Manage store managers, permissions, and security credentials</p>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between font-bold text-slate-700 dark:text-slate-200">
          <span>Active Administrators ({admins.length || 1})</span>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {/* Main admin seed row */}
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs">
                M
              </div>
              <div>
                <p className="font-bold text-slate-900 dark:text-white">INFOSTORS Main Administrator</p>
                <p className="text-[11px] text-slate-400">infostors24@gmail.com • +91 8695222581</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300 font-bold text-[10px] uppercase">
                Main Admin
              </span>
              <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                <Shield className="w-3.5 h-3.5" />
                <span>Protected</span>
              </span>
            </div>
          </div>

          {admins
            .filter(a => a.email !== 'infostors24@gmail.com')
            .map(admin => (
              <div key={admin.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-xs">
                    {admin.fullName?.charAt(0) || 'A'}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">{admin.fullName}</p>
                    <p className="text-[11px] text-slate-400">{admin.email} • +91 {admin.mobile}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-bold text-[10px] uppercase">
                    {admin.role}
                  </span>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};
