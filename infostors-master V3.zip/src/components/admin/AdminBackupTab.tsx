import React, { useState } from 'react';
import { Database, Download, Upload, CheckCircle2 } from 'lucide-react';
import { Product, Category, Order, StoreSettings } from '../../types';

interface AdminBackupTabProps {
  products: Product[];
  categories: Category[];
  orders: Order[];
  storeSettings: StoreSettings;
  adminToken: string;
  updateStoreSettings: (settings: StoreSettings) => void;
}

export const AdminBackupTab: React.FC<AdminBackupTabProps> = ({
  products,
  categories,
  orders,
  storeSettings,
}) => {
  const [downloaded, setDownloaded] = useState(false);

  const handleExportBackup = () => {
    const backupData = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      storeSettings,
      products,
      categories,
      orders,
    };

    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(backupData, null, 2))}`;
    const link = document.createElement('a');
    link.href = jsonString;
    link.download = `infostors_snapshot_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 3000);
  };

  return (
    <div className="space-y-6 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      <div className="pb-3 border-b border-slate-200 dark:border-slate-800">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Database className="w-4 h-4 text-blue-600" />
          <span>Database Snapshot & Backup Tools</span>
        </h3>
        <p className="text-[11px] text-slate-400">Download snapshot backups of all products, settings, and orders</p>
      </div>

      <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div>
          <h4 className="font-bold text-sm text-slate-900 dark:text-white">Export Full Store Snapshot (JSON)</h4>
          <p className="text-slate-500 mt-1">
            Downloads complete store state including catalog products ({products.length}), categories ({categories.length}), orders ({orders.length}), and branding configurations.
          </p>
        </div>

        <button
          onClick={handleExportBackup}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl inline-flex items-center gap-2 shadow-xs cursor-pointer"
        >
          {downloaded ? <CheckCircle2 className="w-4 h-4" /> : <Download className="w-4 h-4" />}
          <span>{downloaded ? 'Snapshot Exported!' : 'Export Complete Store Backup'}</span>
        </button>
      </div>
    </div>
  );
};
