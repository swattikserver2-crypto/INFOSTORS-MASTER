import React, { useState, useEffect } from 'react';
import { X, MessageCircle, Send, Check } from 'lucide-react';
import { Order, StoreSettings } from '../../types';

interface OrderWhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  storeSettings: StoreSettings;
}

export const OrderWhatsAppModal: React.FC<OrderWhatsAppModalProps> = ({
  isOpen,
  onClose,
  order,
  storeSettings,
}) => {
  const [message, setMessage] = useState('');

  // Update default message when order or open state changes
  useEffect(() => {
    if (order) {
      setMessage(
        `Hi ${order.customer?.fullName || 'Valued Customer'}! Your ${storeSettings.storeName || 'INFOSTORS'} order #${order.orderId} for ₹${order.totalAmount} is currently ${order.status.toUpperCase()}.${
          order.trackingId ? ` Courier: ${order.courierPartner || 'Delhivery Express'}, Tracking: ${order.trackingId}.` : ''
        } Thank you!`
      );
    }
  }, [order, storeSettings.storeName]);

  if (!isOpen || !order) return null;

  const handleSend = () => {
    const phone = order.customer?.phone?.replace(/[^0-9]/g, '');
    const fullPhone = phone?.startsWith('91') ? phone : `91${phone}`;
    window.open(`https://wa.me/${fullPhone}?text=${encodeURIComponent(message)}`, '_blank');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-emerald-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Send WhatsApp Notice</h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          <div>
            <p className="text-slate-500 font-medium">Recipient:</p>
            <p className="font-bold text-slate-900 dark:text-white">{order.customer?.fullName} (+91 {order.customer?.phone})</p>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Message Content</label>
            <textarea
              rows={4}
              value={message}
              onChange={e => setMessage(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSend}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Open WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
