import React, { useState } from 'react';
import { Smartphone, Save, Check, Download } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const AdminPwaSettingsTab: React.FC = () => {
  const { storeSettings, updateStoreSettings } = useShop();
  const [pwa, setPwa] = useState(storeSettings.pwaSettings || {
    appName: 'INFOSTORS',
    appShortName: 'INFOSTORS',
    appIconUrl: '/app-icon.svg',
    appDescription: 'Smart Gadgets | Better Life',
    installButtonText: 'Install App',
    installBannerText: 'Install INFOSTORS App',
    bannerEnabled: true,
    pwaInstallEnabled: true,
    themeColor: '#020617',
    backgroundColor: '#020617',
  });
  const [saved, setSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateStoreSettings({ ...storeSettings, pwaSettings: pwa });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5 text-xs text-slate-800 dark:text-slate-100 max-w-3xl">
      <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-blue-600" />
            <span>Progressive Web App (PWA) Settings</span>
          </h3>
          <p className="text-[11px] text-slate-400">Configure install banners and mobile app capabilities</p>
        </div>

        <button
          type="submit"
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
        >
          {saved ? <Check className="w-4 h-4 text-white" /> : <Save className="w-4 h-4" />}
          <span>{saved ? 'Saved!' : 'Save PWA Settings'}</span>
        </button>
      </div>

      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">App Name</label>
            <input
              type="text"
              value={pwa.appName}
              onChange={e => setPwa({ ...pwa, appName: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Short Name</label>
            <input
              type="text"
              value={pwa.appShortName}
              onChange={e => setPwa({ ...pwa, appShortName: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Banner Text</label>
          <input
            type="text"
            value={pwa.installBannerText}
            onChange={e => setPwa({ ...pwa, installBannerText: e.target.value })}
            className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
          />
        </div>

        <div className="flex items-center gap-6 pt-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.bannerEnabled}
              onChange={e => setPwa({ ...pwa, bannerEnabled: e.target.checked })}
              className="rounded-md text-blue-600 focus:ring-blue-500"
            />
            <span className="font-semibold text-slate-700 dark:text-slate-300">Show Top Install Banner</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.pwaInstallEnabled !== false}
              onChange={e => setPwa({ ...pwa, pwaInstallEnabled: e.target.checked })}
              className="rounded-md text-blue-600 focus:ring-blue-500"
            />
            <span className="font-semibold text-slate-700 dark:text-slate-300">Enable PWA Install Button</span>
          </label>
        </div>
      </div>
    </form>
  );
};
