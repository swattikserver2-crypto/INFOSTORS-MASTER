import React, { useState } from 'react';
import { BarChart3, Download, Calendar, IndianRupee, FileSpreadsheet, TrendingUp } from 'lucide-react';
import { Order, Product, StoreSettings } from '../../types';

interface AdminReportsTabProps {
  orders: Order[];
  products: Product[];
  storeSettings: StoreSettings;
}

export const AdminReportsTab: React.FC<AdminReportsTabProps> = ({
  orders,
  products,
  storeSettings,
}) => {
  const [range, setRange] = useState('30d');

  const totalSales = orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
  const deliveredOrders = orders.filter(o => o.status === 'delivered');

  const exportSalesCsv = () => {
    const headers = ['Order ID', 'Date', 'Customer Name', 'Phone', 'Total Amount', 'Status', 'Payment Method'];
    const rows = orders.map(o => [
      o.orderId,
      new Date(o.date).toISOString().split('T')[0],
      `"${o.customer?.fullName || ''}"`,
      o.customer?.phone || '',
      o.totalAmount,
      o.status,
      o.paymentMethod,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `infostors_sales_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-blue-600" />
            <span>Sales Reports & Financial Analytics</span>
          </h3>
          <p className="text-[11px] text-slate-400">Export GST-compliant reports and monitor revenue streams</p>
        </div>

        <button
          onClick={exportSalesCsv}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Export Sales CSV</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
          <p className="text-[11px] font-bold text-slate-400 uppercase">Gross Revenue</p>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">₹{totalSales.toLocaleString('en-IN')}</p>
        </div>

        <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
          <p className="text-[11px] font-bold text-slate-400 uppercase">Total Orders</p>
          <p className="text-2xl font-black text-blue-600 mt-1">{orders.length}</p>
        </div>

        <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
          <p className="text-[11px] font-bold text-slate-400 uppercase">Delivered Orders</p>
          <p className="text-2xl font-black text-emerald-600 mt-1">{deliveredOrders.length}</p>
        </div>
      </div>
    </div>
  );
};
