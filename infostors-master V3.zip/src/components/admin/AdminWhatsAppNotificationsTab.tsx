import React, { useState } from 'react';
import { MessageCircle, Save, Check } from 'lucide-react';
import { StoreSettings } from '../../types';

interface AdminWhatsAppNotificationsTabProps {
  storeSettings: StoreSettings;
  updateStoreSettings: (settings: StoreSettings) => void;
}

export const AdminWhatsAppNotificationsTab: React.FC<AdminWhatsAppNotificationsTabProps> = ({
  storeSettings,
  updateStoreSettings,
}) => {
  const [settings, setSettings] = useState(
    storeSettings.whatsappNotificationSettings || {
      enabledTypes: {
        order_confirmed: true,
        order_processing: true,
        order_dispatched: true,
        out_for_delivery: true,
        order_delivered: true,
        order_cancelled: true,
        payment_received: true,
      },
      templates: {
        order_confirmed: { title: 'Confirmed', body: 'Order #{order_id} confirmed for ₹{total_amount}.' },
        order_processing: { title: 'Processing', body: 'Order #{order_id} is being packed.' },
        order_dispatched: { title: 'Dispatched', body: 'Order #{order_id} dispatched via {courier} (AWB: {tracking_id}).' },
        out_for_delivery: { title: 'Out for Delivery', body: 'Package out for delivery today.' },
        order_delivered: { title: 'Delivered', body: 'Order #{order_id} delivered.' },
        order_cancelled: { title: 'Cancelled', body: 'Order #{order_id} cancelled.' },
        payment_received: { title: 'Payment', body: 'Payment received for #{order_id}.' },
      },
      businessNumber: '+91 94778 39200',
      autoPromptOnStatusChange: true,
    }
  );
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateStoreSettings({ ...storeSettings, whatsappNotificationSettings: settings });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-emerald-600" />
            <span>WhatsApp Notification Engine</span>
          </h3>
          <p className="text-[11px] text-slate-400">Configure automated customer SMS and WhatsApp notification templates</p>
        </div>

        <button
          type="submit"
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
        >
          {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{saved ? 'Saved!' : 'Save WhatsApp Settings'}</span>
        </button>
      </div>

      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div>
          <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
            Official Business WhatsApp Number
          </label>
          <input
            type="text"
            value={settings.businessNumber || ''}
            onChange={e => setSettings({ ...settings, businessNumber: e.target.value })}
            className="w-full max-w-md px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
          />
        </div>

        <div className="pt-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={settings.autoPromptOnStatusChange !== false}
              onChange={e => setSettings({ ...settings, autoPromptOnStatusChange: e.target.checked })}
              className="rounded-md text-emerald-600 focus:ring-emerald-500"
            />
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Prompt 1-Click WhatsApp notification on order status transitions
            </span>
          </label>
        </div>
      </div>
    </form>
  );
};
