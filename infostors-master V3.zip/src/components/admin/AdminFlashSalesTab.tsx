import React, { useState } from 'react';
import { Flame, Plus, Trash2, Check, X, Clock, AlertCircle, Sparkles, Package } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { FlashSale, FlashSaleItem } from '../../types';

export const AdminFlashSalesTab: React.FC = () => {
  const { flashSales, products, saveFlashSale, deleteFlashSale } = useShop();

  const [isCreating, setIsCreating] = useState(false);
  const [editingSale, setEditingSale] = useState<FlashSale | null>(null);

  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [discountPercentage, setDiscountPercentage] = useState(50);
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0, 16));
  const [endDate, setEndDate] = useState(new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 16));
  const [isActive, setIsActive] = useState(true);
  const [saleItems, setSaleItems] = useState<FlashSaleItem[]>([]);

  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleOpenCreate = () => {
    setEditingSale(null);
    setTitle('Midnight Flash Drop');
    setSubtitle('Exclusive limited stock gadgets up to 60% off!');
    setDiscountPercentage(50);
    setStartDate(new Date().toISOString().slice(0, 16));
    setEndDate(new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 16));
    setIsActive(true);
    
    // Default pick 3 products with discounted price
    const sampleItems = products.slice(0, 4).map(p => ({
      productId: p.id,
      flashPrice: Math.round(p.price * 0.7),
      flashStock: 25,
      soldCount: 0,
    }));
    setSaleItems(sampleItems);
    setIsCreating(true);
  };

  const handleOpenEdit = (fs: FlashSale) => {
    setEditingSale(fs);
    setTitle(fs.title);
    setSubtitle(fs.subtitle);
    setDiscountPercentage(fs.discountPercentage);
    setStartDate(fs.startDate.slice(0, 16));
    setEndDate(fs.endDate.slice(0, 16));
    setIsActive(fs.isActive);
    setSaleItems(fs.products || []);
    setIsCreating(true);
  };

  const handleToggleProduct = (productId: string) => {
    const exists = saleItems.find(item => item.productId === productId);
    if (exists) {
      setSaleItems(prev => prev.filter(item => item.productId !== productId));
    } else {
      const prod = products.find(p => p.id === productId);
      if (prod) {
        setSaleItems(prev => [
          ...prev,
          {
            productId: prod.id,
            flashPrice: Math.round(prod.price * (1 - discountPercentage / 100)),
            flashStock: 20,
            soldCount: 0,
          },
        ]);
      }
    }
  };

  const handleItemChange = (productId: string, field: 'flashPrice' | 'flashStock', val: number) => {
    setSaleItems(prev => prev.map(item => item.productId === productId ? { ...item, [field]: val } : item));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMessage('Sale title is required.');
      return;
    }
    if (saleItems.length === 0) {
      setErrorMessage('Select at least one product for the flash sale.');
      return;
    }

    try {
      const payload: Partial<FlashSale> = {
        title: title.trim(),
        subtitle: subtitle.trim(),
        discountPercentage: Number(discountPercentage),
        startDate: new Date(startDate).toISOString(),
        endDate: new Date(endDate).toISOString(),
        isActive,
        products: saleItems,
      };

      if (editingSale) {
        payload.id = editingSale.id;
      }

      const res = await saveFlashSale(payload);
      if (res.success) {
        setStatusMessage(editingSale ? 'Flash sale updated.' : 'Flash sale launched successfully.');
        setIsCreating(false);
        setEditingSale(null);
        setTimeout(() => setStatusMessage(null), 3000);
      } else {
        setErrorMessage(res.error || 'Failed to save flash sale.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error saving flash sale.');
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!window.confirm(`Delete flash sale "${name}"?`)) return;
    const res = await deleteFlashSale(id);
    if (res.success) {
      setStatusMessage('Flash sale deleted.');
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white">
        <div>
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-rose-500" />
            <h2 className="text-lg font-black tracking-tight">Flash Sale & Urgency Campaigns</h2>
            <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-400/30 px-2 py-0.5 rounded-full font-bold">
              {flashSales.length} Total
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Display explosive high-discount campaigns with live ticking countdown timers on the customer homepage.
          </p>
        </div>

        <button
          type="button"
          onClick={handleOpenCreate}
          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Launch Flash Sale</span>
        </button>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{statusMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Editor Modal */}
      {isCreating && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-400" />
              <span>{editingSale ? 'Edit Flash Sale' : 'Create Flash Sale'}</span>
            </h3>
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="text-slate-400 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Campaign Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Super Sunday Rush"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:border-rose-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Subtitle / Punchline</label>
                <input
                  type="text"
                  placeholder="e.g. Up to 60% Off limited inventory"
                  value={subtitle}
                  onChange={e => setSubtitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:border-rose-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Headline Discount (%)</label>
                <input
                  type="number"
                  min={5}
                  max={95}
                  value={discountPercentage}
                  onChange={e => setDiscountPercentage(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:border-rose-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Start Date & Time</label>
                <input
                  type="datetime-local"
                  required
                  value={startDate}
                  onChange={e => setStartDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:border-rose-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">End Date & Time</label>
                <input
                  type="datetime-local"
                  required
                  value={endDate}
                  onChange={e => setEndDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:border-rose-500 outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-6">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={e => setIsActive(e.target.checked)}
                    className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer"
                  />
                  <span>Active & Visible to Customers</span>
                </label>
              </div>
            </div>

            {/* Select Products for Flash Sale */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <label className="block text-xs font-bold text-slate-200">
                Select Products & Configure Special Flash Price
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-60 overflow-y-auto pr-1">
                {products.map(p => {
                  const isSelected = saleItems.some(item => item.productId === p.id);
                  const selectedItem = saleItems.find(item => item.productId === p.id);

                  return (
                    <div
                      key={p.id}
                      className={`p-2.5 rounded-xl border text-xs flex flex-col justify-between transition ${
                        isSelected
                          ? 'border-rose-500/80 bg-rose-500/10'
                          : 'border-slate-800 bg-slate-800/40 opacity-70'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleProduct(p.id)}
                          className="w-4 h-4 text-rose-600 rounded cursor-pointer"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="font-bold text-white truncate">{p.name}</p>
                          <p className="text-[10px] text-slate-400">Regular: ₹{p.price}</p>
                        </div>
                      </div>

                      {isSelected && (
                        <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-700/60">
                          <div>
                            <span className="text-[10px] text-slate-400">Flash Price (₹)</span>
                            <input
                              type="number"
                              min={1}
                              value={selectedItem?.flashPrice || 0}
                              onChange={e => handleItemChange(p.id, 'flashPrice', Number(e.target.value))}
                              className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-bold text-rose-400"
                            />
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-400">Allocated Stock</span>
                            <input
                              type="number"
                              min={1}
                              value={selectedItem?.flashStock || 10}
                              onChange={e => handleItemChange(p.id, 'flashStock', Number(e.target.value))}
                              className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-bold text-white"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl cursor-pointer shadow-md"
              >
                {editingSale ? 'Update Flash Sale' : 'Launch Sale'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Existing Flash Sales List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {flashSales.map(fs => {
          const now = new Date().toISOString();
          const isOngoing = fs.isActive && fs.startDate <= now && fs.endDate >= now;

          return (
            <div
              key={fs.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white flex flex-col justify-between space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-black text-sm text-white">{fs.title}</h3>
                    <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-400/30 px-2 py-0.5 rounded-full font-bold">
                      {fs.discountPercentage}% OFF
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{fs.subtitle}</p>
                </div>

                <span
                  className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full ${
                    isOngoing
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-pulse'
                      : fs.isActive
                      ? 'bg-amber-500/20 text-amber-300'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {isOngoing ? 'LIVE NOW' : fs.isActive ? 'SCHEDULED' : 'ENDED'}
                </span>
              </div>

              <div className="text-xs text-slate-400 space-y-1 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                <div className="flex justify-between">
                  <span>Products Included:</span>
                  <span className="font-bold text-white">{fs.products?.length || 0} items</span>
                </div>
                <div className="flex justify-between">
                  <span>Ends At:</span>
                  <span className="font-mono text-white">
                    {new Date(fs.endDate).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
                  </span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => handleOpenEdit(fs)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs rounded-xl transition cursor-pointer"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(fs.id, fs.title)}
                  className="px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-semibold text-xs rounded-xl transition cursor-pointer"
                >
                  Delete
                </button>
              </div>
            </div>
          );
        })}

        {flashSales.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-500 bg-slate-900/50 border border-slate-800 rounded-2xl">
            No flash sales configured yet. Click "Launch Flash Sale" above to start an urgency deal!
          </div>
        )}
      </div>
    </div>
  );
};
