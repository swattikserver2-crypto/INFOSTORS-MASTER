import React, { useState, useEffect } from 'react';
import { ShieldCheck, Clock, User, Activity } from 'lucide-react';
import { parseApiResponse } from '../../utils/safeApi';

interface AuditLogsTabProps {
  adminProfile: any;
  adminToken: string;
}

export const AuditLogsTab: React.FC<AuditLogsTabProps> = ({ adminProfile, adminToken }) => {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (adminToken) {
      setLoading(true);
      fetch('/api/admin/audit-logs', {
        headers: { Authorization: `Bearer ${adminToken}` },
      })
        .then(res => parseApiResponse(res))
        .then(res => {
          if (res.ok && res.data?.logs) {
            setLogs(res.data.logs);
          }
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  }, [adminToken]);

  return (
    <div className="space-y-5 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-600" />
            <span>Immutable Security & System Audit Trail</span>
          </h3>
          <p className="text-[11px] text-slate-400">
            Real-time security logs recording administrative actions, payment updates, and logins
          </p>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between font-bold text-slate-700 dark:text-slate-200">
          <span>Recent Activity Events ({logs.length})</span>
        </div>

        {loading ? (
          <div className="py-12 text-center text-slate-400">Loading audit trail...</div>
        ) : logs.length === 0 ? (
          <div className="p-6 text-center text-slate-400 text-xs">
            No audit events logged yet in current session.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {logs.map(log => (
              <div key={log.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">{log.action}</p>
                  <p className="text-[11px] text-slate-400">{log.adminEmail || 'System'} • {log.targetSummary || ''}</p>
                </div>
                <div className="text-right text-[11px] text-slate-400">
                  {new Date(log.timestamp).toLocaleTimeString('en-IN', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
