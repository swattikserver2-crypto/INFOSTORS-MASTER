import React from 'react';
import { Star, Heart, ShoppingBag, Zap, Check } from 'lucide-react';
import { Product } from '../types';
import { useShop } from '../context/ShopContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    addToCart,
    buyNow,
    toggleWishlist,
    isInWishlist,
    setSelectedProduct,
    cart,
  } = useShop();

  const isLiked = isInWishlist(product.id);
  const cartItem = cart.find(item => item.product.id === product.id);
  const isInCart = Boolean(cartItem);

  return (
    <div
      className="group relative bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 hover:border-blue-400/80 dark:hover:border-blue-500/50 shadow-xs hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-300 flex flex-col overflow-hidden"
      id={`product-card-${product.id}`}
    >
      {/* Top Badges & Wishlist */}
      <div className="absolute top-2.5 inset-x-2.5 flex items-center justify-between z-10 pointer-events-none">
        <div className="flex flex-col gap-1 items-start">
          {product.discount > 0 && (
            <span className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-extrabold text-[11px] px-2 py-0.5 rounded-md shadow-sm">
              {product.discount}% OFF
            </span>
          )}
          {product.badge && (
            <span className="bg-amber-100 dark:bg-amber-950/70 text-amber-900 dark:text-amber-300 border border-amber-300/80 dark:border-amber-700 font-bold text-[9px] px-1.5 py-0.5 rounded tracking-wide uppercase">
              {product.badge}
            </span>
          )}
        </div>

        <button
          onClick={e => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`pointer-events-auto p-2 rounded-full backdrop-blur-md transition-all cursor-pointer shadow-xs ${
            isLiked
              ? 'bg-rose-50 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 ring-1 ring-rose-300 dark:ring-rose-800'
              : 'bg-white/90 dark:bg-slate-800/90 text-slate-400 hover:text-rose-500 hover:bg-white dark:hover:bg-slate-800'
          }`}
          aria-label={isLiked ? 'Remove from wishlist' : 'Add to wishlist'}
          title={isLiked ? 'In Wishlist' : 'Add to Wishlist'}
        >
          <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
        </button>
      </div>

      {/* Product Image Area */}
      <div
        onClick={() => setSelectedProduct(product)}
        className="relative w-full pt-[85%] bg-slate-50/70 dark:bg-slate-800/40 overflow-hidden cursor-pointer flex items-center justify-center p-4"
      >
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="absolute inset-0 w-full h-full object-contain p-4 group-hover:scale-108 transition-transform duration-300 ease-out"
        />

        {/* Stock warning if low */}
        {product.stock <= 15 && (
          <div className="absolute bottom-2 left-2 bg-amber-500/90 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded">
            Only {product.stock} left!
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="p-2.5 sm:p-3.5 md:p-4 flex-1 flex flex-col justify-between space-y-2 sm:space-y-3">
        <div
          onClick={() => setSelectedProduct(product)}
          className="cursor-pointer space-y-1 sm:space-y-1.5"
        >
          <div className="text-[10px] sm:text-[11px] font-semibold text-slate-400 dark:text-slate-400 uppercase tracking-wider">
            {product.brand}
          </div>

          <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100 line-clamp-2 leading-snug group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
            {product.name}
          </h3>

          <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
            {product.shortDescription}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-1.5 pt-0.5 sm:pt-1">
            <div className="flex items-center gap-1 bg-emerald-600 text-white text-[11px] sm:text-xs font-bold px-1.5 py-0.5 rounded">
              <span>{product.rating}</span>
              <Star className="w-3 h-3 fill-white text-white" />
            </div>
            <span className="text-[11px] sm:text-xs text-slate-400 dark:text-slate-400 font-medium">
              ({product.reviewsCount.toLocaleString('en-IN')})
            </span>
            <span className="text-[9px] sm:text-[10px] font-bold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 border border-blue-100 dark:border-blue-900 px-1.5 py-0.5 rounded ml-auto">
              Assured
            </span>
          </div>
        </div>

        {/* Price and Action Buttons */}
        <div className="space-y-2 sm:space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-baseline gap-1.5 sm:gap-2 flex-wrap">
            <span className="text-base sm:text-lg md:text-xl font-black text-slate-950 dark:text-white tabular-nums">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-[11px] sm:text-xs text-slate-400 line-through tabular-nums">
                ₹{product.originalPrice.toLocaleString('en-IN')}
              </span>
            )}
          </div>

          {/* Buttons: Add to Cart & Buy Now - Responsive side-by-side with compact mobile labels */}
          <div className="grid grid-cols-2 gap-1.5 sm:gap-2 pt-0.5">
            <button
              type="button"
              onClick={e => {
                e.stopPropagation();
                addToCart(product, 1);
              }}
              className={`py-2 px-1.5 sm:px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer select-none min-w-0 w-full ${
                isInCart
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/60'
                  : 'bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 hover:text-blue-700 dark:hover:text-blue-300 border border-slate-200/80 dark:border-slate-700 hover:border-blue-200'
              }`}
              id={`add-to-cart-${product.id}`}
              title={isInCart ? `Added (${cartItem?.quantity}) to cart` : 'Add to Cart'}
            >
              {isInCart ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span className="hidden sm:inline whitespace-nowrap leading-none">Added ({cartItem?.quantity})</span>
                  <span className="sm:hidden whitespace-nowrap leading-none">Added</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
                  <span className="hidden sm:inline whitespace-nowrap leading-none">Add to Cart</span>
                  <span className="sm:hidden whitespace-nowrap leading-none">Add</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={e => {
                e.stopPropagation();
                buyNow(product, 1);
              }}
              className="py-2 px-1.5 sm:px-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white shadow-xs hover:shadow-md hover:shadow-blue-500/20 transition-all flex items-center justify-center gap-1 cursor-pointer select-none min-w-0 w-full"
              id={`buy-now-${product.id}`}
              title="Buy Now with Instant Express Checkout"
            >
              <Zap className="w-3.5 h-3.5 fill-white shrink-0" />
              <span className="hidden sm:inline whitespace-nowrap leading-none">Buy Now</span>
              <span className="sm:hidden whitespace-nowrap leading-none">Buy</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
