import React, { useState, useEffect } from 'react';
import { Smartphone, Download } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

interface AppInstallNavButtonProps {
  variant?: 'header' | 'mobile';
  className?: string;
}

export const AppInstallNavButton: React.FC<AppInstallNavButtonProps> = ({
  variant = 'header',
  className = '',
}) => {
  const { storeSettings } = useShop();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const pwa = storeSettings.pwaSettings;
  if (pwa?.pwaInstallEnabled === false) return null;

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      setDeferredPrompt(null);
    } else if (pwa?.apkDownloadUrl) {
      window.open(pwa.apkDownloadUrl, '_blank');
    } else {
      alert('To install, open your browser menu and choose "Add to Home Screen" or "Install App".');
    }
  };

  return (
    <button
      onClick={handleInstall}
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
        variant === 'header'
          ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-800'
          : 'bg-blue-600 text-white hover:bg-blue-500'
      } ${className}`}
      title="Install INFOSTORS Progressive Web App"
    >
      <Smartphone className="w-3.5 h-3.5" />
      <span>{pwa?.installButtonText || 'Install App'}</span>
    </button>
  );
};
