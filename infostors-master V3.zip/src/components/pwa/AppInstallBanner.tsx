import React, { useState, useEffect } from 'react';
import { Smartphone, Download, X } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const AppInstallBanner: React.FC = () => {
  const { storeSettings } = useShop();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const pwa = storeSettings.pwaSettings;
  if (!pwa?.bannerEnabled || dismissed) return null;

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setDismissed(true);
      }
      setDeferredPrompt(null);
    } else if (pwa?.apkDownloadUrl) {
      window.open(pwa.apkDownloadUrl, '_blank');
    }
  };

  return (
    <div className="w-full bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 text-white px-3 py-2 text-xs flex items-center justify-between shadow-xs z-30">
      <div className="flex items-center gap-2 max-w-[80%]">
        <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
          <Smartphone className="w-4 h-4 text-white" />
        </div>
        <div className="truncate">
          <span className="font-bold">{pwa?.installBannerText || 'Install INFOSTORS App'}</span>
          <span className="hidden sm:inline text-blue-200 ml-1.5">— Fast checkout and real-time tracking</span>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={handleInstall}
          className="px-3 py-1 rounded-lg bg-white text-blue-700 hover:bg-blue-50 font-bold text-[11px] shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{pwa?.installButtonText || 'Install'}</span>
        </button>
        <button
          onClick={() => setDismissed(true)}
          className="p-1 text-white/80 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
