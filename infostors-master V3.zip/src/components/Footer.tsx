import React from 'react';
import { Phone, Mail, MapPin, ShieldCheck, Truck, RotateCcw, Heart } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { InfostorsLogo } from './InfostorsLogo';

export const Footer: React.FC = () => {
  const { storeSettings, setPolicyModal, setSelectedCategory } = useShop();

  return (
    <footer className="w-full bg-slate-900 text-slate-300 border-t border-slate-800 text-xs mt-12 pb-20 md:pb-6">
      {/* Value props rail */}
      <div className="border-b border-slate-800 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-6 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-xs">Free Nationwide Delivery</p>
              <p className="text-[11px] text-slate-400">On all orders above ₹{storeSettings.freeDeliveryMin || 499}</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-xs">{storeSettings.returnWindow || '7 Days Replacement'}</p>
              <p className="text-[11px] text-slate-400">Hassle-free guarantee</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-xs">100% Secure Checkout</p>
              <p className="text-[11px] text-slate-400">UPI, Cards, NetBanking, COD</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-xs">Direct Support</p>
              <p className="text-[11px] text-slate-400">{storeSettings.helpline || '+91 94778 39200'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main footer links */}
      <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand column */}
        <div className="space-y-3">
          {storeSettings.logoUrl ? (
            <img
              src={storeSettings.logoUrl}
              alt={storeSettings.storeName || 'INFOSTORS'}
              className="h-10 w-auto max-w-[200px] object-contain"
            />
          ) : (
            <InfostorsLogo className="h-10 w-auto" />
          )}
          <p className="text-slate-400 text-xs leading-relaxed">
            {storeSettings.tagline || 'Smart Gadgets | Better Life'} — Premium lifestyle electronics, fast GaN chargers, audio, smart home and ambient lighting.
          </p>
        </div>

        {/* Categories */}
        <div className="space-y-2">
          <h4 className="font-bold text-white text-xs uppercase tracking-wider">Top Categories</h4>
          <ul className="space-y-1 text-slate-400">
            <li>
              <button
                onClick={() => setSelectedCategory('audio-sound')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Audio & Sound
              </button>
            </li>
            <li>
              <button
                onClick={() => setSelectedCategory('mobile-accessories')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Mobile Accessories
              </button>
            </li>
            <li>
              <button
                onClick={() => setSelectedCategory('rgb-lights')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                RGB Smart Lights
              </button>
            </li>
            <li>
              <button
                onClick={() => setSelectedCategory('smart-home')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Smart Home
              </button>
            </li>
          </ul>
        </div>

        {/* Customer Care & Policies */}
        <div className="space-y-2">
          <h4 className="font-bold text-white text-xs uppercase tracking-wider">Customer Policies</h4>
          <ul className="space-y-1 text-slate-400">
            <li>
              <button
                onClick={() => setPolicyModal('returns')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Replacement Policy
              </button>
            </li>
            <li>
              <button
                onClick={() => setPolicyModal('privacy')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Privacy Policy
              </button>
            </li>
            <li>
              <button
                onClick={() => setPolicyModal('terms')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Terms of Service
              </button>
            </li>
          </ul>
        </div>

        {/* Contact info */}
        <div className="space-y-2">
          <h4 className="font-bold text-white text-xs uppercase tracking-wider">Contact & Office</h4>
          <p className="text-slate-400 flex items-start gap-2">
            <MapPin className="w-4 h-4 shrink-0 text-blue-400 mt-0.5" />
            <span>{storeSettings.officeAddress || 'Kolkata 700084, India'}</span>
          </p>
          <p className="text-slate-400 flex items-center gap-2">
            <Mail className="w-4 h-4 shrink-0 text-blue-400" />
            <span>{storeSettings.email || 'contactinfostors@gmail.com'}</span>
          </p>
          <p className="text-slate-400 flex items-center gap-2">
            <Phone className="w-4 h-4 shrink-0 text-blue-400" />
            <span>{storeSettings.helpline || '+91 94778 39200'}</span>
          </p>
        </div>
      </div>

      {/* Bottom copyright */}
      <div className="border-t border-slate-800 py-4 px-4 text-center text-slate-500 text-[11px]">
        <p>© {new Date().getFullYear()} {storeSettings.storeName || 'INFOSTORS'} Enterprises. All rights reserved.</p>
      </div>
    </footer>
  );
};
