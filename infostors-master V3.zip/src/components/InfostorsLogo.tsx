import React from 'react';

interface InfostorsLogoProps {
  className?: string;
  showTagline?: boolean;
  logoUrl?: string;
}

export const InfostorsLogo: React.FC<InfostorsLogoProps> = ({
  className = 'h-10 w-auto',
  showTagline = true,
  logoUrl,
}) => {
  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt="INFOSTORS - Smart Gadgets | Better Life"
        className={`object-contain ${className}`}
      />
    );
  }

  return (
    <div className={`inline-flex flex-col items-center justify-center select-none ${className}`}>
      <div className="flex items-center gap-1.5 leading-none">
        <span className="font-extrabold tracking-tight text-xl sm:text-2xl text-blue-600 dark:text-blue-400">
          INFO
        </span>
        <span className="font-extrabold tracking-tight text-xl sm:text-2xl text-slate-900 dark:text-white">
          STORS
        </span>
        <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
      </div>
      {showTagline && (
        <span className="text-[9px] sm:text-[10px] uppercase font-bold tracking-widest text-slate-500 dark:text-slate-400 mt-0.5">
          Smart Gadgets | Better Life
        </span>
      )}
    </div>
  );
};
