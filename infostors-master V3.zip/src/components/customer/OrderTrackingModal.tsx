import React, { useState } from 'react';
import { X, Search, Package, Truck, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialOrderId?: string;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  initialOrderId = '',
}) => {
  const { orders } = useShop();
  const [searchId, setSearchId] = useState(initialOrderId);
  const [searchedOrder, setSearchedOrder] = useState<any>(null);
  const [hasSearched, setHasSearched] = useState(false);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchId.trim().toUpperCase();
    const found = orders.find(
      o => o.orderId?.toUpperCase() === query || o.orderId?.toUpperCase().includes(query)
    );
    setSearchedOrder(found || null);
    setHasSearched(true);
  };

  const getStatusStep = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'confirmed':
      case 'processing':
        return 1;
      case 'dispatched':
      case 'shipped':
        return 2;
      case 'out_for_delivery':
        return 3;
      case 'delivered':
        return 4;
      default:
        return 1;
    }
  };

  const currentStep = searchedOrder ? getStatusStep(searchedOrder.status) : 1;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Track Order Status</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-5 overflow-y-auto text-xs">
          <form onSubmit={handleSearch} className="flex gap-2">
            <input
              type="text"
              value={searchId}
              onChange={e => setSearchId(e.target.value)}
              placeholder="Enter Order ID (e.g. INF-2026-101)..."
              className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-blue-500 font-mono text-xs uppercase"
              required
            />
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Search className="w-4 h-4" />
              <span>Track</span>
            </button>
          </form>

          {hasSearched && !searchedOrder && (
            <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl text-center text-amber-800 dark:text-amber-300">
              <AlertCircle className="w-6 h-6 mx-auto mb-1 text-amber-600" />
              <p className="font-bold">No order found with ID "{searchId}"</p>
              <p className="text-[11px] mt-0.5">Please verify the order number sent to your SMS or email.</p>
            </div>
          )}

          {searchedOrder && (
            <div className="space-y-4 border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/50 dark:bg-slate-800/40">
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-3">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-mono">Order Number</span>
                  <p className="font-extrabold text-slate-900 dark:text-white font-mono text-sm">
                    {searchedOrder.orderId}
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[11px] font-bold uppercase bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  {searchedOrder.status || 'Confirmed'}
                </span>
              </div>

              {/* Progress Steps */}
              <div className="py-2">
                <div className="flex items-center justify-between relative">
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-slate-200 dark:bg-slate-700 w-full z-0" />
                  <div
                    className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-blue-600 transition-all duration-300 z-0"
                    style={{ width: `${((currentStep - 1) / 3) * 100}%` }}
                  />

                  {['Confirmed', 'Dispatched', 'Out for Delivery', 'Delivered'].map((step, idx) => {
                    const stepNum = idx + 1;
                    const isPassed = stepNum <= currentStep;
                    return (
                      <div key={step} className="flex flex-col items-center relative z-10">
                        <div
                          className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs transition-colors ${
                            isPassed
                              ? 'bg-blue-600 text-white ring-4 ring-blue-100 dark:ring-blue-950'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                          }`}
                        >
                          {isPassed ? <CheckCircle2 className="w-4 h-4" /> : stepNum}
                        </div>
                        <span className="text-[9px] font-semibold text-slate-600 dark:text-slate-400 mt-1">
                          {step}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {searchedOrder.trackingId && (
                <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500">Courier Partner:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {searchedOrder.courierPartner || 'Delhivery Express'}
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500">AWB Tracking ID:</span>
                    <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                      {searchedOrder.trackingId}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
