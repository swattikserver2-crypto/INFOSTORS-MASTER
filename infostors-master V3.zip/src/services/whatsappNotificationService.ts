import { WhatsAppNotificationSettings } from '../types';

export const DEFAULT_WHATSAPP_NOTIFICATION_SETTINGS: WhatsAppNotificationSettings = {
  enabledTypes: {
    order_confirmed: true,
    order_processing: true,
    order_dispatched: true,
    out_for_delivery: true,
    order_delivered: true,
    order_cancelled: true,
    payment_received: true,
  },
  templates: {
    order_confirmed: {
      title: 'Order Confirmed',
      body: 'Hi {customer_name}! Your INFOSTORS order #{order_id} for ₹{total_amount} is confirmed.',
    },
    order_processing: {
      title: 'Order Processing',
      body: 'Hi {customer_name}! Your order #{order_id} is being packed and prepared for shipment.',
    },
    order_dispatched: {
      title: 'Order Dispatched',
      body: 'Hi {customer_name}! Your order #{order_id} has been dispatched via {courier} (Tracking: {tracking_id}).',
    },
    out_for_delivery: {
      title: 'Out for Delivery',
      body: 'Hi {customer_name}! Your INFOSTORS package is out for delivery today. Keep OTP/payment ready!',
    },
    order_delivered: {
      title: 'Order Delivered',
      body: 'Hi {customer_name}! Your order #{order_id} has been delivered. Thank you for choosing INFOSTORS!',
    },
    order_cancelled: {
      title: 'Order Cancelled',
      body: 'Hi {customer_name}! Order #{order_id} has been cancelled. Any payments will be refunded within 5-7 business days.',
    },
    payment_received: {
      title: 'Payment Received',
      body: 'Hi {customer_name}! We have received your payment of ₹{total_amount} for order #{order_id}.',
    },
  },
  businessNumber: '+91 94778 39200',
  autoPromptOnStatusChange: true,
};

export function generateWhatsAppMessage(
  template: string,
  params: Record<string, string | number>
): string {
  let message = template;
  for (const [key, value] of Object.entries(params)) {
    message = message.replace(new RegExp(`{${key}}`, 'g'), String(value));
  }
  return message;
}
