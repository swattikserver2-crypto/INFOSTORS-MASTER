/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_ANON_KEY?: string;
  readonly VITE_APP_MODE?: string;
  readonly VITE_GOOGLE_CLIENT_ID?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

declare module 'bwip-js' {
  interface ToSvgOptions {
    bcid: string;
    text: string;
    scale?: number;
    height?: number;
    width?: number;
    includetext?: boolean;
    textxalign?: string;
    paddingwidth?: number;
    paddingheight?: number;
    [key: string]: any;
  }

  export function toSVG(opts: ToSvgOptions): string;
  export function toSVG(opts: ToSvgOptions, callback: (err?: Error, svg?: string) => void): void;
  export function toCanvas(canvas: HTMLCanvasElement | string, opts: any): HTMLCanvasElement;
  const bwipjs: {
    toSVG: typeof toSVG;
    toCanvas: typeof toCanvas;
    [key: string]: any;
  };
  export default bwipjs;
}
