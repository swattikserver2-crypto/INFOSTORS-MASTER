import React from 'react';
import { AdminProductModal } from './components/AdminProductModal';

export const AdminApp: React.FC = () => {
  return (
    <div className="w-full min-h-screen bg-slate-900 text-slate-100 flex flex-col">
      <AdminProductModal isStandalone={true} />
    </div>
  );
};
