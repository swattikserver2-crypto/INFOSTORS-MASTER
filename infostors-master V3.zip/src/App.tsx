import React, { useState, useEffect } from 'react';
import { ShopProvider } from './context/ShopContext';
import { AdminApp } from './AdminApp';
import { CustomerApp } from './CustomerApp';
import { PreviewEnvironmentSwitcher } from './components/PreviewEnvironmentSwitcher';

/**
 * INFOSTORS Master Unified Application Router.
 * 
 * Includes the Google AI Studio Live Interactive Preview Switcher:
 * [ CUSTOMER STOREFRONT ]   [ ADMIN CONSOLE ]
 * 
 * Both interfaces run seamlessly against the shared ShopProvider state
 * and backend source of truth.
 */
export default function App() {
  const [currentView, setCurrentView] = useState<'customer' | 'admin'>(() => {
    if (typeof window !== 'undefined') {
      const mode = String(import.meta.env.VITE_APP_MODE || '').toLowerCase();
      if (mode === 'admin') return 'admin';
      if (mode === 'customer') return 'customer';
      return window.location.pathname.startsWith('/admin') ? 'admin' : 'customer';
    }
    return 'customer';
  });

  useEffect(() => {
    const handleLocationChange = () => {
      const isAdmin = window.location.pathname.startsWith('/admin');
      setCurrentView(isAdmin ? 'admin' : 'customer');
    };

    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  return (
    <ShopProvider>
      <div className="min-h-screen w-full flex flex-col font-sans antialiased bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200">
        {/* Development & Live Preview Switcher */}
        <PreviewEnvironmentSwitcher
          currentView={currentView}
          onViewChange={setCurrentView}
        />

        {/* Live Active Application View */}
        <div className="flex-1 w-full">
          {currentView === 'admin' ? <AdminApp /> : <CustomerApp />}
        </div>
      </div>
    </ShopProvider>
  );
}

