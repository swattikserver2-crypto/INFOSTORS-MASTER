export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice: number;
  discount: number;
  image: string;
  images?: string[];
  description: string;
  shortDescription: string;
  features: string[];
  stock: number;
  rating: number;
  reviewsCount: number;
  isTrending?: boolean;
  isBestseller?: boolean;
  isNewArrival?: boolean;
  isDeal?: boolean;
  badge?: string;
  brand: string;
  warranty?: string;
}

export interface Category {
  id: string;
  name: string;
  icon?: string;
  emoji: string;
  description: string;
  bannerImage?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Customer {
  id: string; // Business Customer ID, e.g. "CUS-8695222581"
  authUid?: string; // Optional security UID when registered
  fullName: string;
  email: string;
  mobile: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  orderIds?: string[];
  totalOrders?: number;
  totalSpent?: number;
  createdAt: string;
  updatedAt?: string;
  status?: 'active' | 'suspended';
}

export type AdminRole = 'main_admin' | 'admin';
export type AdminStatus = 'active' | 'disabled';

export type AdminPermission =
  | 'view_customers'
  | 'edit_customers'
  | 'delete_customers'
  | 'view_orders'
  | 'edit_orders'
  | 'delete_orders'
  | 'view_products'
  | 'edit_products'
  | 'delete_products'
  | 'manage_admins'
  | 'manage_settings'
  | 'approve_delete_requests';

export interface AdminUser {
  id: string;
  email: string;
  fullName: string;
  mobile: string;
  role: AdminRole;
  status: AdminStatus;
  permissions?: AdminPermission[];
  createdAt: string;
  updatedAt?: string;
  lastLoginAt?: string;
  createdBy?: string;
}

export type DeleteTargetType = 'order' | 'customer';
export type DeleteRequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED' | 'FAILED';

export interface DeleteRequest {
  id: string;
  targetType: DeleteTargetType;
  targetId: string; // Order ID (INF-...) or Customer ID (CUS-...)
  targetSummary: string;
  requestedByEmail: string;
  requestedByName?: string;
  requestedByRole: AdminRole;
  reason: string;
  status: DeleteRequestStatus;
  createdAt: string;
  reviewedByEmail?: string;
  reviewedByName?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  completedAt?: string;
  error?: string;
}

export interface AuditLog {
  id: string;
  adminEmail: string;
  adminName?: string;
  adminUid?: string;
  action: string;
  targetType: string;
  targetId: string;
  reason?: string;
  timestamp: string;
  result: 'SUCCESS' | 'FAILED' | 'REJECTED' | 'SYNC_PENDING';
  details?: string;
}

export interface AdminProfile {
  email: string;
  name: string;
  picture?: string;
  role: 'admin' | 'main_admin';
  mobile?: string;
}

export interface CustomerDetails {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
}

export type PaymentMethod = 'upi' | 'razorpay' | 'cod';

export type PackageStatus = 
  | 'new'
  | 'received'
  | 'confirmed'
  | 'processing'
  | 'packed'
  | 'dispatched'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled'
  | 'return_requested'
  | 'returned'
  | 'refund_pending'
  | 'refunded'
  | 'on_hold'
  | 'archived';

export interface OrderStatusHistoryItem {
  status: PackageStatus;
  timestamp: string;
  note?: string;
  updatedBy?: string;
}

export interface Order {
  orderId: string;
  customerId?: string;
  date: string;
  customer: CustomerDetails;
  items: CartItem[];
  subtotal: number;
  deliveryCharge: number;
  discountSavings: number;
  totalAmount: number;
  tax?: number;
  taxBreakdown?: {
    gstEnabled: boolean;
    gstRate: number;
    gstType: 'inclusive' | 'exclusive';
    gstAmount: number;
    storeGstin?: string;
  };
  b2bDetails?: CustomerB2BDetails;
  paymentMethod: PaymentMethod;
  paymentStatus?: 'pending' | 'authorized' | 'paid' | 'failed' | 'refunded';
  orderStatus?: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'out_for_delivery' | 'delivered' | 'cancelled';
  upiApp?: string;
  upiId?: string;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  paymentFailureReason?: string;
  status: PackageStatus;
  courierPartner?: string;
  trackingId?: string;
  resolution?: string;
  cancellationReason?: string;
  cancelledAt?: string;
  cancelledBy?: string;
  statusHistory?: OrderStatusHistoryItem[];
  estimatedDeliveryDate: string;
}

export interface PaymentSettingsInfo {
  mode: 'test' | 'live';
  status: 'connected' | 'not_configured';
  source: 'admin' | 'env' | 'none';
  keyId: string;
  rawKeyId?: string;
  hasKeySecret: boolean;
  hasWebhookSecret: boolean;
  isConfigured?: boolean;
  isActive?: boolean;
  environment?: 'test' | 'live';
  updatedAt?: string;
  updatedBy?: string;
  auditLogs?: Array<{
    id: string;
    adminEmail: string;
    action: string;
    mode: 'test' | 'live';
    success: boolean;
    timestamp: string;
  }>;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  logoUrl?: string;
  headerLogoHeight?: number;
  helpline: string;
  email: string;
  officeAddress: string;
  freeDeliveryMin: number;
  announcement: string;
  whatsapp: string;
  instagram: string;
  facebook: string;
  youtube: string;
  whatsappUrl?: string;
  returnWindow?: string;

  // Business Profile Details
  businessLegalName?: string; // Registered legal entity name
  ownerName?: string; // Owner / Legal Representative Name
  tradeName?: string; // Registered trade name
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  pincode?: string;
  country?: string;
  phone?: string;
  website?: string;
  pan?: string; // Permanent Account Number (e.g. AAACI1234F)

  // Delivery Charge Configuration
  standardDeliveryCharge: number; // e.g. 49 (or 0 for always free)
  enableFreeDeliveryThreshold: boolean; // If true, orders above freeDeliveryMin get free shipping

  // Full Profile GST Configuration
  gstEnabled: boolean; // ON / OFF toggle for GST
  gstin?: string; // 15-character GST identification number
  gstPercentage: number; // e.g. 18 (%), 12, 5, 28
  gstType: 'inclusive' | 'exclusive'; // 'inclusive' (in product price) or 'exclusive' (added at checkout)
  gstState?: string; // State / Jurisdiction code, e.g. "19 - West Bengal"
  showGstinOnInvoice: boolean; // Show GSTIN on order receipts/invoices
  allowCustomerB2bGst: boolean; // Allow B2B customers to enter their GSTIN on checkout

  // App Install / PWA Configuration
  pwaSettings?: PwaSettings;

  // Premium WhatsApp Order Notifications Configuration
  whatsappNotificationSettings?: WhatsAppNotificationSettings;

  // 4x6 Shipping Label & Thermal Bill Settings (Privacy, Pickup, Branding)
  shippingLabelSettings?: ShippingLabelSettings;

  // Master Extended Settings
  featureFlags?: FeatureFlags;
  themeSettings?: ThemeSettings;
  layoutSettings?: LayoutSettings;
  deliveryApiSettings?: DeliveryApiSettings;
  emailSettings?: EmailSettings;
  loyaltySettings?: LoyaltySettings;
  whatsAppApiSettings?: WhatsAppApiSettings;
}

export interface ShippingLabelSettings {
  showCustomerEmail: boolean; // default false (Privacy)
  showCustomerMobile: boolean; // default true
  showPickupLocation: boolean; // default true
  showPickupContact: boolean; // default true
  showCourierPartner: boolean; // default true
  showTrackingId: boolean; // default true
  showOrderId: boolean; // default true
  showPaymentMethod: boolean; // default true
  showProductDetails: boolean; // default true
  showPrices: boolean; // default true
  showBarcode: boolean; // default true
  showDataMatrix: boolean; // default true
  autoPdfAfterFinalize?: boolean; // default false
  customCourierPartners?: string[]; // Admin managed custom courier list
  pickupLocation?: {
    companyName: string;
    address: string;
    city: string;
    state: string;
    pincode: string;
    contactNumber: string;
  };
  branding?: {
    logoEnabled: boolean;
    logoUrl?: string;
    showOnInvoice: boolean;
    showOnLabel: boolean;
    alignment: 'left' | 'center' | 'right';
    size: 'small' | 'medium' | 'large';
  };
}

export type WhatsAppMessageType = 
  | 'order_confirmed'
  | 'order_processing'
  | 'order_dispatched'
  | 'out_for_delivery'
  | 'order_delivered'
  | 'order_cancelled'
  | 'payment_received';

export interface WhatsAppNotificationSettings {
  enabledTypes: Record<WhatsAppMessageType, boolean>;
  templates: Record<WhatsAppMessageType, {
    title: string;
    body: string;
  }>;
  businessNumber?: string;
  autoPromptOnStatusChange?: boolean;
}

export interface PushNotificationPayload {
  id: string;
  title: string;
  body: string;
  targetAudience: 'individual' | 'selected' | 'segment' | 'all';
  notificationType: 'order_update' | 'special_offer' | 'new_product' | 'restock' | 'promo';
  recipient?: string;
  targetUrl?: string;
  imageUrl?: string;
  sentAt?: string;
  status: 'sent' | 'scheduled' | 'draft';
}

export interface PwaSettings {
  appName: string; // Full App Name
  appShortName: string; // Mobile Launcher Short Name (<= 12 chars)
  appIconUrl: string; // Icon image URL or /app-icon.svg
  appDescription: string; // Short application description
  installButtonText: string; // Action button text (e.g. "Install App")
  installBannerText: string; // Prominent banner notification copy
  bannerEnabled: boolean; // Master toggle to show/hide the install banner
  themeColor: string; // Android status bar / theme color (#020617)
  backgroundColor: string; // Splash screen background color (#020617)
  apkDownloadUrl?: string; // Optional direct APK download link
  showApkDownload?: boolean; // Separate direct download button toggle
  apkButtonText?: string; // Direct download button label
  pwaInstallEnabled?: boolean; // PWA / Install Android App [ ON / OFF ] (Default: true)
  playStoreEnabled?: boolean; // Google Play Store Button [ ON / OFF ] (Default: true)
  playStoreUrl?: string; // Google Play Store URL
}

export const DEFAULT_PWA_SETTINGS: PwaSettings = {
  appName: 'INFOSTORS - Smart Gadgets | Better Life',
  appShortName: 'INFOSTORS',
  appIconUrl: '/app-icon.svg',
  appDescription: 'Discover useful gadgets, electronics, mobile accessories and everyday essentials at great prices with fast shipping across India.',
  installButtonText: 'Install App',
  installBannerText: 'Install our fast Android app for quicker checkout, order tracking & exclusive deals!',
  bannerEnabled: true,
  themeColor: '#020617',
  backgroundColor: '#020617',
  apkDownloadUrl: '',
  showApkDownload: false,
  apkButtonText: 'Download APK',
  pwaInstallEnabled: true,
  playStoreEnabled: true,
  playStoreUrl: '',
};

export interface CustomerB2BDetails {
  companyName?: string;
  gstin?: string;
}

export interface DeliveryLocation {
  pincode: string;
  area?: string;
  city?: string;
  state?: string;
  formattedAddress?: string;
  lat?: number;
  lng?: number;
}

export interface FilterState {
  category: string;
  searchQuery: string;
  sortBy: 'featured' | 'price-low' | 'price-high' | 'rating' | 'discount';
  sectionFilter?: 'all' | 'trending' | 'bestseller' | 'new' | 'deals';
}

// ─────────────────────────────────────────────────────────────
// 13 MASTER ECOMMERCE EXTENDED FEATURES & CONFIGURATION
// ─────────────────────────────────────────────────────────────

export interface FeatureFlags {
  coupons: boolean;
  flashSale: boolean;
  reviews: boolean;
  returns: boolean;
  refunds: boolean;
  deliveryApi: boolean;
  whatsappApi: boolean;
  emailNotifications: boolean;
  loyalty: boolean;
  wallet: boolean;
  offers: boolean;
  multiVendor: boolean;
  advancedReports: boolean;
}

export const DEFAULT_FEATURE_FLAGS: FeatureFlags = {
  coupons: true,
  flashSale: true,
  reviews: true,
  returns: true,
  refunds: true,
  deliveryApi: true,
  whatsappApi: true,
  emailNotifications: true,
  loyalty: true,
  wallet: true,
  offers: true,
  multiVendor: true,
  advancedReports: true,
};

export type ThemeMode = 'light' | 'dark' | 'system';

export interface ThemeSettings {
  mode: ThemeMode;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  buttonColor: string;
  backgroundColor: string;
  cardStyle: 'elevated' | 'bordered' | 'minimal' | 'flat';
  borderRadius: 'none' | 'sm' | 'md' | 'lg' | 'xl' | 'full';
  typographyScale: 'compact' | 'normal' | 'large';
  headerStyle: 'modern' | 'minimal' | 'dense';
  sidebarStyle: 'dark' | 'light' | 'accent';
  productCardStyle: 'compact' | 'standard' | 'dense';
}

export const DEFAULT_THEME_SETTINGS: ThemeSettings = {
  mode: 'light',
  primaryColor: '#2563eb',
  secondaryColor: '#4f46e5',
  accentColor: '#0ea5e9',
  buttonColor: '#2563eb',
  backgroundColor: '#f8fafc',
  cardStyle: 'bordered',
  borderRadius: 'xl',
  typographyScale: 'normal',
  headerStyle: 'modern',
  sidebarStyle: 'dark',
  productCardStyle: 'compact',
};

export interface LayoutSettings {
  customer: {
    productGridDensity: 'compact' | 'comfortable' | 'dense';
    cardStyle: 'compact-modern' | 'classic' | 'minimal';
    headerDensity: 'compact' | 'normal';
    categoryLayout: 'horizontal-rail' | 'grid' | 'carousel';
    sectionSpacing: 'compact' | 'normal';
    showHeroBanner: boolean;
    showDealsSection: boolean;
    showTrendingSection: boolean;
    showBestsellerSection: boolean;
    showNewArrivalsSection: boolean;
    showOffersSection: boolean;
    showFlashSaleSection: boolean;
  };
  admin: {
    sidebarCollapsed: boolean;
    tableDensity: 'compact' | 'normal' | 'relaxed';
    dashboardCards: '4-col' | '3-col' | '2-col';
    layoutMode: 'default' | 'dense';
  };
}

export const DEFAULT_LAYOUT_SETTINGS: LayoutSettings = {
  customer: {
    productGridDensity: 'compact',
    cardStyle: 'compact-modern',
    headerDensity: 'compact',
    categoryLayout: 'horizontal-rail',
    sectionSpacing: 'compact',
    showHeroBanner: true,
    showDealsSection: true,
    showTrendingSection: true,
    showBestsellerSection: true,
    showNewArrivalsSection: true,
    showOffersSection: true,
    showFlashSaleSection: true,
  },
  admin: {
    sidebarCollapsed: false,
    tableDensity: 'compact',
    dashboardCards: '4-col',
    layoutMode: 'dense',
  },
};

// 1. Coupon / Discount
export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderValue: number;
  maxDiscount?: number;
  startDate: string;
  expiryDate: string;
  usageLimit?: number;
  usageCount: number;
  perCustomerLimit: number;
  firstOrderOnly: boolean;
  isActive: boolean;
  applicableCategories?: string[];
  applicableProducts?: string[];
  createdAt: string;
}

// 2. Flash Sale
export interface FlashSaleItem {
  productId: string;
  flashPrice: number;
  flashStock: number;
  soldCount: number;
}

export interface FlashSale {
  id: string;
  title: string;
  subtitle: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  discountPercentage: number;
  products: FlashSaleItem[];
  bannerImage?: string;
}

// 3. Reviews & Ratings
export interface Review {
  id: string;
  productId: string;
  productName?: string;
  customerId: string;
  customerName: string;
  rating: number; // 1-5
  comment: string;
  images?: string[];
  verifiedPurchase: boolean;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

// 4. Returns
export interface ReturnItem {
  productId: string;
  name: string;
  quantity: number;
  price: number;
}

export interface ReturnRequest {
  id: string;
  orderId: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  items: ReturnItem[];
  reason: string;
  description: string;
  status: 'requested' | 'approved' | 'pickup_scheduled' | 'returned' | 'completed' | 'rejected';
  createdAt: string;
  updatedAt: string;
  adminNotes?: string;
  evidenceUrl?: string;
}

// 5. Refunds
export interface RefundRecord {
  id: string;
  returnId?: string;
  orderId: string;
  customerId: string;
  customerName?: string;
  amount: number;
  method: 'original_payment' | 'wallet' | 'manual';
  status: 'requested' | 'approved' | 'processing' | 'completed' | 'rejected' | 'failed';
  failureReason?: string;
  transactionRef?: string;
  createdAt: string;
  processedAt?: string;
  notes?: string;
}

// 6. Delivery API
export interface DeliveryApiSettings {
  provider: 'delhivery' | 'shiprocket' | 'bluedart' | 'xpressbees' | 'custom';
  apiKeyEncrypted?: string;
  apiSecretEncrypted?: string;
  liveMode: boolean;
  webhookUrl?: string;
  autoGenerateWaybill: boolean;
  status: 'NOT CONFIGURED' | 'CONNECTED' | 'ERROR';
  lastTestedAt?: string;
}

// 7. WhatsApp API
export interface WhatsAppApiSettings {
  provider: 'wati' | 'interakt' | 'aisensy' | 'meta_cloud' | 'custom';
  apiKeyEncrypted?: string;
  phoneNumberId?: string;
  enabledTemplates: Record<string, boolean>;
  status: 'NOT CONFIGURED' | 'CONNECTED' | 'ERROR';
  lastTestedAt?: string;
}

// 8. Email Notifications
export interface EmailSettings {
  provider: 'resend' | 'smtp' | 'sendgrid';
  apiKey?: string;
  fromEmail: string;
  enabledEvents: {
    welcome: boolean;
    orderConfirmation: boolean;
    shippingUpdate: boolean;
    delivery: boolean;
    cancellation: boolean;
    returnUpdate: boolean;
    refundUpdate: boolean;
    passwordReset: boolean;
  };
  status: 'NOT CONFIGURED' | 'CONNECTED' | 'ERROR';
  lastTestedAt?: string;
}

// 9. Loyalty / Rewards
export interface LoyaltyTransaction {
  id: string;
  customerId: string;
  customerName?: string;
  points: number;
  type: 'earned' | 'redeemed' | 'adjusted' | 'expired';
  description: string;
  orderId?: string;
  createdAt: string;
}

export interface LoyaltySettings {
  pointsPer100Spent: number; // e.g. 5 points per Rs 100
  pointValueInInr: number; // e.g. 1 point = Rs 1
  minRedemptionPoints: number; // e.g. 50
  maxRedemptionPerOrder: number; // e.g. 500
  pointsExpiryDays: number; // e.g. 365
}

// 10. Customer Wallet
export interface WalletTransaction {
  id: string;
  customerId: string;
  customerName?: string;
  amount: number;
  type: 'credit' | 'debit';
  description: string;
  referenceId?: string;
  createdAt: string;
}

// 11. Promotional Offers
export interface PromotionalOffer {
  id: string;
  title: string;
  description: string;
  code?: string;
  bannerImage?: string;
  categoryId?: string;
  minAmount?: number;
  discountText: string;
  badge?: string;
  validTill: string;
  isActive: boolean;
  createdAt: string;
}

// 12. Vendor / Multi-Vendor
export interface Vendor {
  id: string;
  storeName: string;
  ownerName: string;
  email: string;
  phone: string;
  commissionRate: number; // percentage (e.g. 10%)
  status: 'active' | 'pending' | 'suspended';
  logoUrl?: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  pan?: string;
  gstin?: string;
  totalProducts: number;
  totalSales: number;
  rating: number;
  createdAt: string;
}

// 13. Advanced Reports & Analytics
export interface ReportSummary {
  totalRevenue: number;
  totalOrders: number;
  totalCustomers: number;
  averageOrderValue: number;
  pendingReturns: number;
  totalRefunded: number;
  couponDiscountsTotal: number;
  flashSaleRevenue: number;
  topSellingProducts: { id: string; name: string; salesCount: number; revenue: number }[];
  salesByCategory: { categoryId: string; name: string; revenue: number; orderCount: number }[];
  revenueByDay: { date: string; revenue: number; orders: number }[];
  recentActivity: { id: string; type: string; summary: string; timestamp: string }[];
}
