# INFOSTORS — SUPABASE DATABASE & SECURITY ARCHITECTURE
## PRODUCTION SYSTEM SPECIFICATION & RELATIONAL FOUNDATION

**Document Version:** 1.0.0  
**Classification:** CENTRAL DATABASE ARCHITECTURE & SOURCE OF TRUTH  
**Engine:** PostgreSQL 15+ (Supabase)  
**Security Standard:** Strict Row Level Security (RLS) + Multi-Role Access Control (RBAC)  
**Contract Alignment:** `INFOSTORS_FINAL_DATA_STRUCTURE_API_CONTRACT.md` (v1.0.0)  

---

## 1. ARCHITECTURAL OBJECTIVE & TOPOLOGY

The database serves as the **CENTRAL SOURCE OF TRUTH** across the INFOSTORS ecosystem. It coordinates customer browsing, purchasing, inventory decrementing, online payments, dispatch fulfillment, tax compliance, and business analytics.

```
+-----------------------------------------------------------------------------+
|                           CENTRAL SOURCE OF TRUTH                           |
|                        SUPABASE / POSTGRESQL DATABASE                       |
+-----------------------------------------------------------------------------+
          ▲                                                 ▲
          │                                                 │
          ▼                                                 ▼
+-----------------------+                         +-----------------------+
|  SHARED SERVICE LAYER |                         |  SHARED SERVICE LAYER |
|  REPOSITORY INTERFACE |                         |  REPOSITORY INTERFACE |
+-----------------------+                         +-----------------------+
          ▲                                                 ▲
          │                                                 │
          ▼                                                 ▼
+-----------------------+                         +-----------------------+
|   CUSTOMER STOREFRONT |                         |   ADMIN PANEL SUITE   |
|   (Customer Shopping) |                         |   (Store Operations)  |
+-----------------------+                         +-----------------------+
```

### Architectural Guarantees:
1. **Provider Independence**: Application UI components (Customer Website and Admin Panel) interface exclusively with repository abstractions (`IProductRepository`, `IOrderRepository`, etc.). The database implementation uses a swappable adapter pattern.
2. **Parity**: Products, categories, customers, inventory, orders, and settings share the exact same definitions across Admin and Customer storefronts.
3. **Zero Google Sheets / Apps Script**: The system does not depend on, connect to, or synchronize with any external spreadsheet services.

---

## 2. CENTRAL ENTITY-RELATIONSHIP MAP

```
  [roles] (1) <---------- (N) [role_permissions] (N) ----------> (1) [permissions]
     ▲
     │
    (1)
     │
  [admin_users] (1) <---------- (N) [delete_requests]
     │
    (1)
     │
  [audit_logs]


  [customers] (1) <---------- (N) [customer_addresses]
     ▲
     │
    (1)
     │
    (N)
  [orders] (1) <---------- (N) [order_items] (N) ----------> (1) [products]
     │                                                             ▲
     ├─── (1) <---> (N) [order_status_history]                     │
     │                                                            (1)
     └─── (1) <---> (N) [payment_transactions]                     │
                                                                  (N)
                                                           [inventory_logs]
                                                                   ▲
                                                                   │
                                                           [categories] (1)
```

---

## 3. RELATIONAL SCHEMA SPECIFICATION

### 3.1. Entity: `roles`, `permissions`, `role_permissions`
- **Purpose**: Defines granular role-based access control.
- **Roles**:
  - `main_admin`: Full system authority, payment secrets management, and destructive delete approvals.
  - `admin`: Order fulfillment, catalog updates, warehouse inventory management, and customer messaging.
  - `support`: Read-only access to customer profiles and orders for troubleshooting.
- **Permissions**:
  `products.read`, `products.write`, `orders.read`, `orders.write`, `customers.read`, `customers.write`, `inventory.read`, `inventory.write`, `payments.read`, `payments.write`, `shipping.write`, `reports.read`, `settings.write`, `users.write`, `backup.manage`, `activity.read`.

### 3.2. Entity: `admin_users`
- **Table**: `public.admin_users`
- **Primary Key**: `id` (`admin_infostors24_main` or `adm_<t36>_<r4>`)
- **Foreign Keys**: `auth_user_id` -> `auth.users(id)`, `role` -> `roles(id)`
- **Columns**:
  - `id` (TEXT, PK): Unique admin identifier.
  - `auth_user_id` (UUID, UNIQUE): Supabase Auth user reference.
  - `email` (TEXT, UNIQUE): Registered administrative email.
  - `mobile` (TEXT): 10-digit mobile number.
  - `full_name` (TEXT): Display name.
  - `role` (TEXT, FK): Assigned role.
  - `status` (TEXT): `'active'` or `'disabled'`.
  - `created_by` (TEXT): Email of authoring administrator.
  - `created_at` (TIMESTAMPTZ): Default `now()`.
  - `updated_at` (TIMESTAMPTZ): Default `now()`.

### 3.3. Entity: `customers` & `customer_addresses`
- **Table**: `public.customers`
- **Primary Key**: `id` (`CUS-<10_digit_mobile>` or `cust-<t36>-<r4>`)
- **Columns**:
  - `id` (TEXT, PK): Monotonic or phone-derived customer ID.
  - `auth_user_id` (UUID, UNIQUE, NULLABLE): Linked Supabase Auth ID (null for guest checkout).
  - `full_name` (TEXT): Real customer name.
  - `email` (TEXT, UNIQUE): Primary contact email.
  - `mobile` (TEXT, UNIQUE): Valid 10-digit Indian mobile number (`/^[6-9][0-9]{9}$/`).
  - `address`, `city`, `state`, `pincode` (TEXT): Default shipping coordinates.
  - `total_orders` (INTEGER): Monotonic order counter.
  - `total_spent` (NUMERIC): Lifetime gross spend in INR.
  - `status` (TEXT): `'active'` or `'suspended'`.
  - `created_at`, `updated_at` (TIMESTAMPTZ).

### 3.4. Entity: `categories`
- **Table**: `public.categories`
- **Primary Key**: `id` (Slug string, e.g. `'electronics'`, `'audio-sound'`)
- **Columns**:
  - `id` (TEXT, PK): URL slug.
  - `name` (TEXT): Display name.
  - `emoji` (TEXT): Visual emoji icon.
  - `description` (TEXT): Category summary.
  - `icon_name` (TEXT): Lucide icon reference name.
  - `banner_image` (TEXT): Optional header banner URL.
  - `display_order` (INTEGER): Navigation ordering.
  - `created_at`, `updated_at` (TIMESTAMPTZ).

### 3.5. Entity: `products`
- **Table**: `public.products`
- **Primary Key**: `id` (e.g. `'inf-101'`)
- **Foreign Keys**: `category_id` -> `categories(id)`
- **Columns**:
  - `id` (TEXT, PK): Unique SKU/catalog ID.
  - `name` (TEXT): Product title.
  - `category_id` (TEXT, FK): Category reference.
  - `brand` (TEXT): Brand name (e.g. `'INFOSTORS SoundLab'`).
  - `price` (NUMERIC): Selling price in INR.
  - `original_price` (NUMERIC): MRP in INR.
  - `discount_percentage` (INTEGER): Generated virtual column.
  - `image_url` (TEXT): Primary thumbnail.
  - `gallery_images` (JSONB): Array of image URLs.
  - `short_description` (TEXT): Bullet/card summary.
  - `description` (TEXT): Full markdown description.
  - `features` (JSONB): String array of key specifications.
  - `stock` (INTEGER): Warehouse units available (>= 0).
  - `rating` (NUMERIC): 1.0 to 5.0 star score.
  - `reviews_count` (INTEGER): Total user reviews count.
  - `is_trending`, `is_bestseller`, `is_new_arrival`, `is_deal` (BOOLEAN).
  - `badge` (TEXT): Optional visual pill badge.
  - `warranty` (TEXT): Warranty coverage statement.
  - `is_active` (BOOLEAN): Master catalog toggle.
  - `created_at`, `updated_at` (TIMESTAMPTZ).

### 3.6. Entity: `inventory_logs`
- **Table**: `public.inventory_logs`
- **Primary Key**: `id` (UUID)
- **Foreign Keys**: `product_id` -> `products(id)`
- **Purpose**: Auditable ledger tracking all stock movements (+/-).
- **Columns**: `id`, `product_id`, `change_amount`, `previous_stock`, `new_stock`, `reason` (`'order_placed'`, `'order_cancelled'`, `'admin_adjustment'`, `'restock'`, `'damage_writeoff'`), `order_id`, `notes`, `created_by`, `created_at`.

### 3.7. Entity: `orders` & `order_items`
- **Table**: `public.orders`
- **Primary Key**: `id` (Format: `INF-YYYYMMDD-XXXX`)
- **Foreign Keys**: `customer_id` -> `customers(id)`
- **Columns**:
  - `id` (TEXT, PK): Monotonic daily sequential order number.
  - `customer_id` (TEXT, FK): Customer account reference.
  - `customer_name`, `customer_phone`, `customer_email`: Delivery identity.
  - `shipping_address`, `city`, `state`, `pincode`: Delivery destination.
  - `subtotal`, `discount_amount`, `shipping_fee`, `tax_amount`, `grand_total`: Strict server-verified calculations.
  - `currency` (TEXT): Fixed `'INR'`.
  - `payment_method` (TEXT): `'razorpay'`, `'upi'`, or `'cod'`.
  - `payment_status` (TEXT): `'pending'`, `'authorized'`, `'paid'`, `'failed'`, `'refunded'`.
  - `order_status` (TEXT): `'pending'`, `'confirmed'`, `'processing'`, `'shipped'`, `'delivered'`, `'cancelled'`.
  - `package_status` (TEXT): `'received'`, `'dispatched'`, `'delivered'`, `'cancelled'`.
  - `razorpay_order_id`, `razorpay_payment_id`, `razorpay_signature`: Cryptographic payment verification.
  - `payment_failure_reason` (TEXT): Gateway cancellation diagnostics.
  - `courier_partner` (TEXT): Logistics carrier (e.g. `'Delhivery Express'`, `'Blue Dart'`).
  - `tracking_id` (TEXT): Air Waybill (AWB) number.
  - `estimated_delivery_date` (TEXT): Estimated arrival.
  - `resolution` (TEXT): Cancellation justification or admin fulfillment notes.
  - `b2b_company_name`, `b2b_gstin`: Corporate tax details.
  - `tax_breakdown` (JSONB): Breakdown of CGST, SGST, IGST.
  - `paid_at`, `created_at`, `updated_at` (TIMESTAMPTZ).

- **Table**: `public.order_items`
- **Columns**: `id` (UUID, PK), `order_id` (FK to orders.id ON DELETE CASCADE), `product_id` (FK to products.id), `product_name`, `unit_price`, `quantity`, `total_price`, `image_url`, `created_at`.

### 3.8. Entity: `store_settings` & `payment_settings`
- **Table**: `public.store_settings`: Global profile, helpline, office address, standard shipping charges (₹49), free delivery minimum threshold (₹499), GST policies, PWA settings, thermal label formats.
- **Table**: `public.payment_settings`: Razorpay mode (`'test'`, `'live'`), Key ID, encrypted Key Secret, encrypted Webhook Secret.

### 3.9. Entity: `delete_requests` (Two-Man Rule Destruction Governance)
- **Table**: `public.delete_requests`
- **Purpose**: Enforces two-person review for destructive operations. Any admin can initiate a request; only the Primary Main Admin (`infostors24@gmail.com`) can approve execution.

### 3.10. Entity: `audit_logs`
- **Table**: `public.audit_logs`
- **Purpose**: Immutable security and administrative ledger. Has NO `UPDATE` or `DELETE` policies.

### 3.11. Entity: `customer_messages` & `notifications`
- **Table**: `public.customer_messages`: Isolated private messages / VIP offers between staff and specific customer accounts.
- **Table**: `public.notifications`: Store-wide public announcements and segmented customer notices.

---

## 4. ROW LEVEL SECURITY (RLS) POLICIES

| Table | Policy Name | Permitted Operations | Access Condition / Expression |
|---|---|---|---|
| `products` | Public view active | `SELECT` | `is_active = true OR public.is_admin()` |
| `products` | Admin manage | `INSERT, UPDATE, DELETE` | `public.has_permission('products.write')` |
| `categories` | Public view | `SELECT` | `true` |
| `categories` | Admin manage | `INSERT, UPDATE, DELETE` | `public.has_permission('products.write')` |
| `customers` | Customer own view | `SELECT` | `auth_user_id = auth.uid() OR public.has_permission('customers.read')` |
| `customers` | Customer own edit | `UPDATE` | `auth_user_id = auth.uid() OR public.has_permission('customers.read')` |
| `customer_addresses`| Customer own addresses | `ALL` | `customer_id IN (SELECT id FROM customers WHERE auth_user_id = auth.uid())` |
| `orders` | Customer own orders | `SELECT` | `customer_id IN (SELECT id FROM customers WHERE auth_user_id = auth.uid()) OR public.has_permission('orders.read')` |
| `orders` | Customer create order | `INSERT` | `true` |
| `orders` | Admin update status | `UPDATE` | `public.has_permission('orders.write')` |
| `orders` | Main Admin delete | `DELETE` | `public.is_main_admin()` |
| `store_settings` | Public read rules | `SELECT` | `true` |
| `store_settings` | Admin update settings | `UPDATE` | `public.has_permission('settings.write')` |
| `payment_settings` | Admin view keys | `SELECT` | `public.has_permission('payments.read')` |
| `payment_settings` | Main Admin edit keys | `UPDATE` | `public.is_main_admin()` |
| `audit_logs` | Admin view logs | `SELECT` | `public.has_permission('activity.read')` |
| `audit_logs` | System insert | `INSERT` | `true` (No UPDATE or DELETE exists) |
| `customer_messages`| Customer own inbox | `SELECT` | `customer_id IN (SELECT id FROM customers WHERE auth_user_id = auth.uid()) OR public.is_admin()` |
| `delete_requests` | Admin queue view | `SELECT` | `public.is_admin()` |
| `delete_requests` | Main Admin approve | `UPDATE` | `public.is_main_admin()` |

---

## 5. STORAGE BUCKETS & SECURITY

| Bucket Name | Public Access | Size Limit | Allowed MIME Types | Intended Purpose |
|---|---|---|---|---|
| `product-images` | Yes | 10 MB | `image/jpeg`, `image/png`, `image/webp`, `image/svg+xml` | Product catalog thumbnails & gallery pictures |
| `store-assets` | Yes | 5 MB | `image/jpeg`, `image/png`, `image/webp`, `image/svg+xml`, `application/json` | Store branding logo, PWA icons, hero banners |
| `invoices` | **No** (Private) | 10 MB | `application/pdf` | Customer GST tax invoices (Customer accesses own, Admin accesses all) |
| `shipping-labels` | **No** (Private) | 10 MB | `application/pdf`, `image/png` | 4x6 thermal courier labels with barcodes (Admin only) |

---

## 6. BACKUP, RESTORE & DISASTER RECOVERY

1. **Daily Logical Dump**:
   ```bash
   pg_dump -h <host> -U postgres -d postgres --clean --if-exists -F c -b -v -f infostors_backup_$(date +%Y%m%d).dump
   ```
2. **Snapshot Inclusions**:
   - Schema definitions, table structures, constraints, indexes.
   - Products, categories, store settings, customers, orders, order items.
   - Audit logs, delete requests queue, inventory history logs.
3. **Recovery Considerations**:
   - Master restoration restores table rows with monotonic IDs preserved.
   - Sensitive payment secrets stored as AES-256-CBC ciphertext can only be decrypted with the server's master encryption key (`ENCRYPTION_KEY`).

---

## 7. PROVIDER-INDEPENDENT IMPLEMENTATION PATTERN

```typescript
// Shared Repository Pattern (UI is independent of Supabase)
export interface IOrderRepository {
  getById(id: string): Promise<Order | null>;
  getAll(filters?: OrderFilterOptions): Promise<Order[]>;
  create(order: OrderInput): Promise<Order>;
  updateStatus(id: string, status: PackageStatus, details?: DispatchDetails): Promise<boolean>;
}

// Swappable Backend Adapter:
export class SupabaseOrderRepository implements IOrderRepository { ... }
export class ExpressLocalOrderRepository implements IOrderRepository { ... }
```
