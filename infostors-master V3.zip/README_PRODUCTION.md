# INFOSTORS Production Master

## Architecture
- Customer and Admin are two application surfaces in the same Vite/Express project.
- Both use the same Supabase PostgreSQL project as the single production data source.
- The Node/Express server is the secure server-side boundary for authentication, orders, inventory, Razorpay secrets, admin operations and protected data.
- Supabase Service Role is SERVER ONLY. Never expose it as `VITE_*`.
- `server/data.json` is not a runtime database and is excluded from the production package.

## Required production environment
```env
NODE_ENV=production
PORT=3000
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_KEY
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVER_ONLY_SERVICE_ROLE_KEY
JWT_SECRET=LONG_RANDOM_SECRET
ENCRYPTION_KEY=LONG_RANDOM_SECRET
GOOGLE_CLIENT_ID=YOUR_GOOGLE_OAUTH_CLIENT_ID
INITIAL_MAIN_ADMIN_PASSWORD_HASH=OPTIONAL_BCRYPT_HASH_FOR_FIRST_BOOTSTRAP
```

## Database setup
Run the existing non-destructive migrations in `supabase/migrations/` in order. Then run:
`20260926000005_production_server_bridge.sql`.

Do not run destructive SQL. Do not drop/truncate/reset existing production data.

## Build
```bash
npm install --legacy-peer-deps
npm run lint
npm run build
npm start
```

## Health check
After deployment:
`GET /health`

Expected:
```json
{"ok":true,"service":"INFOSTORS","database":"supabase"}
```

## Hosting portability
The app requires a Node.js-capable hosting environment because the Express API is part of the production runtime. Set the same environment variables on any new host, deploy the same build, and point the domain to the new host. The Supabase database does not move when hosting changes.

## Payment
Razorpay and UPI flows remain in the existing application. Credentials are handled server-side and encrypted at rest with `ENCRYPTION_KEY`. The browser never receives Key Secret or Webhook Secret. COD remains available independently.

## Developer customization
Use the existing components, context, repositories, server routes and Supabase migrations. Add database changes as a new timestamped migration; never rewrite or reset existing migrations/data. Add API contracts and UI components without bypassing the secure server boundary for protected operations.
