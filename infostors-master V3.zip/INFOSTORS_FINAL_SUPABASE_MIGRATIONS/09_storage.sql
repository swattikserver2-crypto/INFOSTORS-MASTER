-- ============================================================================
-- INFOSTORS FINAL SUPABASE MASTER BUILD — MIGRATION 09: STORAGE BUCKETS & POLICIES
-- Target Project ID: oewerfftzqklptdsdfrm
-- Safety: Non-destructive, idempotent
-- ============================================================================

-- Create storage buckets for INFOSTORS assets and documents
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
    (
        'product-images', 
        'product-images', 
        true, 
        10485760, -- 10MB limit
        ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml']
    ),
    (
        'store-assets', 
        'store-assets', 
        true, 
        5242880, -- 5MB limit
        ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml', 'application/json']
    ),
    (
        'invoices', 
        'invoices', 
        false, -- Private bucket
        10485760, 
        ARRAY['application/pdf']
    ),
    (
        'shipping-labels', 
        'shipping-labels', 
        false, -- Private bucket
        10485760, 
        ARRAY['application/pdf', 'image/png']
    )
ON CONFLICT (id) DO UPDATE SET
    public = EXCLUDED.public,
    file_size_limit = EXCLUDED.file_size_limit,
    allowed_mime_types = EXCLUDED.allowed_mime_types;

-- ----------------------------------------------------------------------------
-- STORAGE POLICIES
-- ----------------------------------------------------------------------------

-- 1. Product Images: Public Read, Admin Write
DROP POLICY IF EXISTS "Public read product images" ON storage.objects;
CREATE POLICY "Public read product images"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'product-images');

DROP POLICY IF EXISTS "Admins can upload product images" ON storage.objects;
CREATE POLICY "Admins can upload product images"
    ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'product-images' AND public.has_permission('products.write'));

DROP POLICY IF EXISTS "Admins can update product images" ON storage.objects;
CREATE POLICY "Admins can update product images"
    ON storage.objects FOR UPDATE
    USING (bucket_id = 'product-images' AND public.has_permission('products.write'));

DROP POLICY IF EXISTS "Admins can delete product images" ON storage.objects;
CREATE POLICY "Admins can delete product images"
    ON storage.objects FOR DELETE
    USING (bucket_id = 'product-images' AND public.has_permission('products.write'));

-- 2. Store Assets (Logo, Favicon, Banners): Public Read, Admin Write
DROP POLICY IF EXISTS "Public read store assets" ON storage.objects;
CREATE POLICY "Public read store assets"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'store-assets');

DROP POLICY IF EXISTS "Admins can manage store assets" ON storage.objects;
CREATE POLICY "Admins can manage store assets"
    ON storage.objects FOR ALL
    USING (bucket_id = 'store-assets' AND public.has_permission('settings.write'))
    WITH CHECK (bucket_id = 'store-assets' AND public.has_permission('settings.write'));

-- 3. Invoices (Tax Invoices): Customer can read own, Admin can read all
DROP POLICY IF EXISTS "Customer can read own invoice" ON storage.objects;
CREATE POLICY "Customer can read own invoice"
    ON storage.objects FOR SELECT
    USING (
        bucket_id = 'invoices' 
        AND (
            public.is_admin()
            OR (auth.uid() IS NOT NULL AND name LIKE (auth.uid()::text || '/%'))
        )
    );

DROP POLICY IF EXISTS "Server and Admins can upload invoices" ON storage.objects;
CREATE POLICY "Server and Admins can upload invoices"
    ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'invoices' AND (public.is_admin() OR auth.role() = 'service_role'));

-- 4. Shipping Labels: Admins ONLY
DROP POLICY IF EXISTS "Admins can access shipping labels" ON storage.objects;
CREATE POLICY "Admins can access shipping labels"
    ON storage.objects FOR ALL
    USING (bucket_id = 'shipping-labels' AND public.has_permission('orders.write'))
    WITH CHECK (bucket_id = 'shipping-labels' AND public.has_permission('orders.write'));
