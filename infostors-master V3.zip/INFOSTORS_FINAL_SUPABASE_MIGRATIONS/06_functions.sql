-- ============================================================================
-- INFOSTORS FINAL SUPABASE MASTER BUILD — MIGRATION 06: STORED FUNCTIONS
-- Target Project ID: oewerfftzqklptdsdfrm
-- Safety: Non-destructive, idempotent
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. AUTOMATIC UPDATED_AT TIMESTAMP FUNCTION
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ----------------------------------------------------------------------------
-- 2. MONOTONIC COLLISION-SAFE ORDER ID GENERATOR
-- Format: INF-YYYYMMDD-XXXX (e.g. INF-20260926-0001)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.generate_order_id()
RETURNS TEXT AS $$
DECLARE
    date_prefix TEXT;
    today_count INTEGER;
    candidate_id TEXT;
BEGIN
    -- Format date in Asia/Kolkata (IST) timezone
    date_prefix := 'INF-' || to_char(timezone('Asia/Kolkata', now()), 'YYYYMMDD');
    
    -- Count existing orders placed today
    SELECT count(*) INTO today_count
    FROM public.orders
    WHERE id LIKE date_prefix || '-%';
    
    today_count := today_count + 1;
    candidate_id := date_prefix || '-' || lpad(today_count::TEXT, 4, '0');
    
    -- Guarantee uniqueness against race conditions
    WHILE EXISTS (SELECT 1 FROM public.orders WHERE id = candidate_id) LOOP
        today_count := today_count + 1;
        candidate_id := date_prefix || '-' || lpad(today_count::TEXT, 4, '0');
    END LOOP;
    
    RETURN candidate_id;
END;
$$ LANGUAGE plpgsql VOLATILE;

-- ----------------------------------------------------------------------------
-- 3. AUTOMATIC ORDER STATUS HISTORY RECORDER
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.record_order_status_change()
RETURNS TRIGGER AS $$
BEGIN
    IF (OLD.order_status IS DISTINCT FROM NEW.order_status) OR (OLD.package_status IS DISTINCT FROM NEW.package_status) THEN
        INSERT INTO public.order_status_history (
            order_id,
            previous_status,
            new_status,
            changed_by,
            notes
        ) VALUES (
            NEW.id,
            COALESCE(OLD.order_status, '') || ' (' || COALESCE(OLD.package_status, '') || ')',
            COALESCE(NEW.order_status, '') || ' (' || COALESCE(NEW.package_status, '') || ')',
            COALESCE(current_setting('app.current_user', true), 'system'),
            NEW.resolution
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ----------------------------------------------------------------------------
-- 4. ATOMIC INVENTORY STOCK DEDUCTION TRIGGER FUNCTION
-- Acquires row-level lock, decrements stock, ensures non-negative, and audits movement
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.deduct_inventory_for_order_item()
RETURNS TRIGGER AS $$
DECLARE
    curr_stock INTEGER;
BEGIN
    -- Retrieve current product stock with row lock
    SELECT stock INTO curr_stock
    FROM public.products
    WHERE id = NEW.product_id
    FOR UPDATE;

    IF curr_stock IS NULL THEN
        RAISE EXCEPTION 'Product % does not exist in catalog', NEW.product_id;
    END IF;

    IF curr_stock < NEW.quantity THEN
        RAISE EXCEPTION 'Insufficient inventory for product %. Available: %, Requested: %', 
            NEW.product_id, curr_stock, NEW.quantity;
    END IF;

    -- Decrement product stock atomically
    UPDATE public.products
    SET stock = stock - NEW.quantity
    WHERE id = NEW.product_id;

    -- Record auditable inventory movement
    INSERT INTO public.inventory_logs (
        product_id,
        change_amount,
        previous_stock,
        new_stock,
        reason,
        order_id,
        notes,
        created_by
    ) VALUES (
        NEW.product_id,
        -NEW.quantity,
        curr_stock,
        curr_stock - NEW.quantity,
        'order_placed',
        NEW.order_id,
        'Order placement auto-deduction for ' || NEW.order_id,
        'system'
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ----------------------------------------------------------------------------
-- 5. RBAC HELPER FUNCTIONS (FOR ROW LEVEL SECURITY)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.admin_users
        WHERE auth_user_id = auth.uid()
          AND status = 'active'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION public.is_main_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.admin_users
        WHERE auth_user_id = auth.uid()
          AND role = 'main_admin'
          AND status = 'active'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION public.has_permission(required_permission TEXT)
RETURNS BOOLEAN AS $$
BEGIN
    -- Main admin automatically holds all permissions
    IF public.is_main_admin() THEN
        RETURN true;
    END IF;

    RETURN EXISTS (
        SELECT 1 
        FROM public.admin_users au
        JOIN public.role_permissions rp ON au.role = rp.role_id
        WHERE au.auth_user_id = auth.uid()
          AND au.status = 'active'
          AND rp.permission_id = required_permission
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
