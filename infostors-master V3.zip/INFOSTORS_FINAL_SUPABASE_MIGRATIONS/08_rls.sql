-- ============================================================================
-- INFOSTORS FINAL SUPABASE MASTER BUILD — MIGRATION 08: ROW LEVEL SECURITY
-- Target Project ID: oewerfftzqklptdsdfrm
-- Security: Strict Customer Isolation + Admin RBAC Enforcement
-- Safety: Non-destructive, idempotent
-- ============================================================================

-- Enable RLS across all tables
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delete_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_carts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_wishlists ENABLE ROW LEVEL SECURITY;

-- ----------------------------------------------------------------------------
-- 1. PRODUCTS & CATEGORIES
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Public can view active products" ON public.products;
CREATE POLICY "Public can view active products" 
    ON public.products FOR SELECT 
    USING (is_active = true OR public.is_admin());

DROP POLICY IF EXISTS "Admins with permission can manage products" ON public.products;
CREATE POLICY "Admins with permission can manage products" 
    ON public.products FOR ALL 
    USING (public.has_permission('products.write'))
    WITH CHECK (public.has_permission('products.write'));

DROP POLICY IF EXISTS "Public can view categories" ON public.categories;
CREATE POLICY "Public can view categories" 
    ON public.categories FOR SELECT 
    USING (true);

DROP POLICY IF EXISTS "Admins with permission can manage categories" ON public.categories;
CREATE POLICY "Admins with permission can manage categories" 
    ON public.categories FOR ALL 
    USING (public.has_permission('products.write'))
    WITH CHECK (public.has_permission('products.write'));

-- ----------------------------------------------------------------------------
-- 2. CUSTOMERS & ADDRESSES
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Customer can view own profile" ON public.customers;
CREATE POLICY "Customer can view own profile" 
    ON public.customers FOR SELECT 
    USING (auth_user_id = auth.uid() OR public.has_permission('customers.read'));

DROP POLICY IF EXISTS "Customer can update own profile" ON public.customers;
CREATE POLICY "Customer can update own profile" 
    ON public.customers FOR UPDATE 
    USING (auth_user_id = auth.uid() OR public.has_permission('customers.read'))
    WITH CHECK (auth_user_id = auth.uid() OR public.has_permission('customers.read'));

DROP POLICY IF EXISTS "Customer can manage own addresses" ON public.customer_addresses;
CREATE POLICY "Customer can manage own addresses" 
    ON public.customer_addresses FOR ALL 
    USING (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) OR public.has_permission('customers.read'))
    WITH CHECK (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()));

-- ----------------------------------------------------------------------------
-- 3. ORDERS & ITEMS (IDOR PROTECTED)
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Customer can view own orders" ON public.orders;
CREATE POLICY "Customer can view own orders" 
    ON public.orders FOR SELECT 
    USING (
        customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) 
        OR public.has_permission('orders.read')
    );

DROP POLICY IF EXISTS "Customer can insert order" ON public.orders;
CREATE POLICY "Customer can insert order" 
    ON public.orders FOR INSERT 
    WITH CHECK (true);

DROP POLICY IF EXISTS "Admins with permission can update orders" ON public.orders;
CREATE POLICY "Admins with permission can update orders" 
    ON public.orders FOR UPDATE 
    USING (public.has_permission('orders.write'))
    WITH CHECK (public.has_permission('orders.write'));

DROP POLICY IF EXISTS "Main admin can delete orders" ON public.orders;
CREATE POLICY "Main admin can delete orders" 
    ON public.orders FOR DELETE 
    USING (public.is_main_admin());

DROP POLICY IF EXISTS "Order items readable if order readable" ON public.order_items;
CREATE POLICY "Order items readable if order readable" 
    ON public.order_items FOR SELECT 
    USING (
        order_id IN (
            SELECT id FROM public.orders 
            WHERE customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) 
               OR public.has_permission('orders.read')
        )
    );

DROP POLICY IF EXISTS "Order items insertable" ON public.order_items;
CREATE POLICY "Order items insertable" 
    ON public.order_items FOR INSERT 
    WITH CHECK (true);

DROP POLICY IF EXISTS "Order status history readable" ON public.order_status_history;
CREATE POLICY "Order status history readable" 
    ON public.order_status_history FOR SELECT 
    USING (
        order_id IN (
            SELECT id FROM public.orders 
            WHERE customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) 
               OR public.has_permission('orders.read')
        )
    );

-- ----------------------------------------------------------------------------
-- 4. STORE SETTINGS & PAYMENT SETTINGS (SECRETS SHIELDED)
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Public can view store settings" ON public.store_settings;
CREATE POLICY "Public can view store settings" 
    ON public.store_settings FOR SELECT 
    USING (true);

DROP POLICY IF EXISTS "Admins can update store settings" ON public.store_settings;
CREATE POLICY "Admins can update store settings" 
    ON public.store_settings FOR UPDATE 
    USING (public.has_permission('settings.write'))
    WITH CHECK (public.has_permission('settings.write'));

DROP POLICY IF EXISTS "Admins can view payment settings" ON public.payment_settings;
CREATE POLICY "Admins can view payment settings" 
    ON public.payment_settings FOR SELECT 
    USING (public.has_permission('payments.read'));

DROP POLICY IF EXISTS "Main Admin can update payment settings" ON public.payment_settings;
CREATE POLICY "Main Admin can update payment settings" 
    ON public.payment_settings FOR UPDATE 
    USING (public.is_main_admin())
    WITH CHECK (public.is_main_admin());

-- ----------------------------------------------------------------------------
-- 5. TWO-MAN RULE DELETION REQUESTS & AUDIT LOGS
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Admins can view delete requests" ON public.delete_requests;
CREATE POLICY "Admins can view delete requests" 
    ON public.delete_requests FOR SELECT 
    USING (public.is_admin());

DROP POLICY IF EXISTS "Admins can submit delete requests" ON public.delete_requests;
CREATE POLICY "Admins can submit delete requests" 
    ON public.delete_requests FOR INSERT 
    WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Main Admin can review delete requests" ON public.delete_requests;
CREATE POLICY "Main Admin can review delete requests" 
    ON public.delete_requests FOR UPDATE 
    USING (public.is_main_admin())
    WITH CHECK (public.is_main_admin());

DROP POLICY IF EXISTS "Admins can view audit logs" ON public.audit_logs;
CREATE POLICY "Admins can view audit logs" 
    ON public.audit_logs FOR SELECT 
    USING (public.has_permission('activity.read'));

DROP POLICY IF EXISTS "System and Admins can insert audit logs" ON public.audit_logs;
CREATE POLICY "System and Admins can insert audit logs" 
    ON public.audit_logs FOR INSERT 
    WITH CHECK (true);

-- ----------------------------------------------------------------------------
-- 6. CUSTOMER MESSAGES & NOTIFICATIONS
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Customer can view own messages" ON public.customer_messages;
CREATE POLICY "Customer can view own messages" 
    ON public.customer_messages FOR SELECT 
    USING (
        customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()) 
        OR public.is_admin()
    );

DROP POLICY IF EXISTS "Admins can send customer messages" ON public.customer_messages;
CREATE POLICY "Admins can send customer messages" 
    ON public.customer_messages FOR INSERT 
    WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Customer can update read status of own message" ON public.customer_messages;
CREATE POLICY "Customer can update read status of own message" 
    ON public.customer_messages FOR UPDATE 
    USING (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()))
    WITH CHECK (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()));

DROP POLICY IF EXISTS "Users can view relevant notifications" ON public.notifications;
CREATE POLICY "Users can view relevant notifications" 
    ON public.notifications FOR SELECT 
    USING (
        target_audience = 'all' 
        OR target_customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid())
        OR public.is_admin()
    );

DROP POLICY IF EXISTS "Admins can manage notifications" ON public.notifications;
CREATE POLICY "Admins can manage notifications" 
    ON public.notifications FOR ALL 
    USING (public.is_admin())
    WITH CHECK (public.is_admin());

-- ----------------------------------------------------------------------------
-- 7. CUSTOMER CART & WISHLIST SYNCHRONIZATION
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Customer can manage own cart" ON public.customer_carts;
CREATE POLICY "Customer can manage own cart" 
    ON public.customer_carts FOR ALL 
    USING (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()))
    WITH CHECK (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()));

DROP POLICY IF EXISTS "Customer can manage own wishlist" ON public.customer_wishlists;
CREATE POLICY "Customer can manage own wishlist" 
    ON public.customer_wishlists FOR ALL 
    USING (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()))
    WITH CHECK (customer_id IN (SELECT id FROM public.customers WHERE auth_user_id = auth.uid()));
